# Собирает два самодостаточных файла в корне проекта. Их можно пересылать по одному:
#   Личный-кабинет.html          — сайт целиком (CSS и JS встроены)
#   Личный-кабинет-телефон.html  — витрина экранов в рамке телефона, сайт встроен внутрь
# Исходники лежат в src/. Запуск: python3 build.py
import json, re
S = "src/"
APP, PHONES = "Личный-кабинет.html", "Личный-кабинет-телефон.html"

html = open(S + "index.html").read()
css = open(S + "assets/zk.css").read() + "\n" + open(S + "assets/app.css").read()
html = html.replace('<link rel="stylesheet" href="assets/zk.css">\n  <link rel="stylesheet" href="assets/app.css">', "<style>\n" + css + "</style>")
for f in ("app.js", "zk.js"):
    html = html.replace(f'<script src="assets/{f}"></script>', "<script>\n" + open(S + "assets/" + f).read() + "</script>")
assert "assets/" not in html, re.findall(r".{40}assets/.{40}", html)
open(APP, "w").write(html)

# Витрина не ссылается на соседний файл (иначе у получателя откроется чужой index.html),
# а несёт сайт в себе и показывает его в iframe через blob-ссылку.
ph = open(S + "phones.html").read()
blob = "<script>window.APP_HTML = " + json.dumps(html, ensure_ascii=False).replace("</", "<\\/") + ";</script>\n"
ph = ph.replace("<script>\n  const SCREENS", blob + "<script>\n  const SCREENS", 1)
assert "APP_HTML = " in ph
open(PHONES, "w").write(ph)
print(f"{APP} {len(html) / 1e6:.2f} MB, {PHONES} {len(ph) / 1e6:.2f} MB")
