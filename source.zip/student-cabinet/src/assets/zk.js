// Разделы Учёба, Заявки, Уведомления и Профиль из шаблона «Зачётка» (данные демонстрационные)
(function(){ "use strict";

/* ===== хранилище (только удобства этого браузера) ===== */
const LS = {
  get(k, d){ try{ const v = localStorage.getItem("zk:"+k); return v ? JSON.parse(v) : d; }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem("zk:"+k, JSON.stringify(v)); }catch(e){} }
};

/* ===== иконки ===== */
const I = {
  today:'<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  schedule:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  grades:'<path d="M4 20V5a2 2 0 0 1 2-2h13v14H6a2 2 0 0 0-2 2zm0 0a2 2 0 0 0 2 2h13"/><path d="M9 8h6"/>',
  requests:'<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  inbox:'<path d="M6 16v-5a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  profile:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  pin:'<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  user:'<circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  alert:'<path d="M12 3l9.5 17h-19z"/><path d="M12 10v4M12 17.5v.01"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  arrow:'<path d="M9 6l6 6-6 6"/>',
  close:'<path d="M6 6l12 12M18 6L6 18"/>',
  chat:'<path d="M4 5h16v11H9l-5 4z"/>',
  card:'<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="12" r="2.3"/><path d="M14 10h4M14 14h3"/>',
  doc:'<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/>',
  shield:'<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
  online:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  eye:'<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff:'<path d="M4 4l16 16M9.9 5.8A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-3 3.8M6.2 7.4A16.6 16.6 0 0 0 2.5 12S6 18.5 12 18.5c1.5 0 2.9-.4 4-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  copy:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  flag:'<path d="M5 21V4h11l-1.5 4L16 12H5"/>',
  news:'<path d="M4 5h13v14H6a2 2 0 0 1-2-2zM17 9h3v8a2 2 0 0 1-2 2"/><path d="M8 9h5M8 13h5"/>',
  bolt:'<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3"/>'
};
const ic = (n, cls="i") => `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${I[n]}</svg>`;
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

/* ===== даты ===== */
const DOW = ["Вс","Пн","Вт","Ср","Чт","Пт","Сб"];
const DOWF = ["воскресенье","понедельник","вторник","среда","четверг","пятница","суббота"];
const MON = ["января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря"];
const MONS = ["янв","фев","мар","апр","мая","июн","июл","авг","сен","окт","ноя","дек"];
const now = () => new Date();
const dayStart = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate()+n); return x; };
const fmtDate = d => `${d.getDate()} ${MON[d.getMonth()]}`;
const plural = (n, a, b, c) => { n = Math.abs(n)%100; const n1 = n%10; if(n>10&&n<20) return c; if(n1>1&&n1<5) return b; if(n1===1) return a; return c; };
const daysTo = iso => Math.round((dayStart(new Date(iso)) - dayStart(now()))/864e5);
const relDays = n => n===0 ? "сегодня" : n===1 ? "завтра" : n<0 ? "прошёл" : `через ${n} ${plural(n,"день","дня","дней")}`;
const durTxt = m => { const h = Math.floor(m/60), mm = m%60; return h ? `${h} ч ${String(mm).padStart(2,"0")} мин` : `${mm} мин`; };

function weekInfo(){
  const t = dayStart(now());
  const wd = t.getDay();
  const monday = addDays(t, wd===0 ? -6 : 1-wd);
  const y = t.getMonth() >= 7 ? t.getFullYear() : t.getFullYear()-1;
  const sep1 = new Date(y, 8, 1);
  const sw = sep1.getDay();
  const acadMon = addDays(sep1, sw===0 ? 1 : 1-sw);
  let no = Math.floor((monday - acadMon)/(7*864e5)) + 1;
  if(no < 1 || no > 22) no = 11;
  return { monday, no, odd: no%2===1, todayWd: wd };
}

/* ===== данные студента (пример) ===== */
const STUDENT = {
  fio:"Демо Студент", short:"Студент", initials:"ДС",
  inst:"Институт информационных технологий", program:"09.03.04 Программная инженерия",
  profile:"Разработка программно-информационных систем", course:3, group:"ПИ-31", form:"очная, бюджет",
  funding:"budget",   // budget — бюджет (видна стипендия), contract — договор
  id:"DEMO-001", email:"student@example.invalid", curator:"Демо Куратор"
};
/* три окна профиля: [подпись, значение, скрыто по умолчанию] */
const PROFILE_INFO = [
  {id:"main", t:"Основное", rows:[
    ["Номер зачётной книжки", "DEMO-001-ПИ", true],
    ["Факультет", STUDENT.inst],
    ["Уровень подготовки", "Бакалавриат"],
    ["Направление подготовки", STUDENT.program],
    ["Направленность (профиль)", STUDENT.profile],
    ["Форма обучения", "Очная, бюджет"],
    ["Год поступления", "2024"],
    ["Курс", STUDENT.course + " курс"],
    ["Статус обучения", "Обучается"]]},
  {id:"personal", t:"Личное", rows:[
    ["Корпоративная почта", STUDENT.email, true],
    ["Логин для учебных сервисов", "demo.student", true],
    ["Пароль от почты", "Не задан", true],
    ["Дата рождения", "Не указана"],
    ["Адрес проживания", "Не указан"],
    ["Пол", "Женский"]]},
  {id:"contacts", t:"Контакты", rows:[
    ["Мобильный телефон", "Не указан"],
    ["Личная почта", "demo@example.invalid"],
    ["Telegram", "Не указан"],
    ["ВКонтакте", "Не указан"],
    ["Экстренный контакт", "Не указан"],
    ["Куратор группы", STUDENT.curator + " · o.lebedeva@example.invalid"]]}
];
const SLOTS = [null,["08:30","10:00"],["10:10","11:40"],["11:50","13:20"],["14:00","15:30"],["15:40","17:10"],["17:20","18:50"]];
const TYPE = { lec:["Лекция",""], prac:["Практика","accent"], lab:["Лабораторная","accent"], pe:["Занятие",""] };
const SCHEDULE = {
  1:[
    {n:2, s:"Теория вероятностей и мат. статистика", t:"lec", room:"305", b:"корпус А", who:"Петров Д. С."},
    {n:3, s:"Теория вероятностей и мат. статистика", t:"prac", room:"412", b:"корпус А", who:"Петров Д. С."},
    {n:4, s:"Базы данных", t:"lab", room:"228", b:"корпус Б", who:"Лебедева О. И.", change:{kind:"room", old:"214", text:"Лабораторная пройдёт в аудитории 228-Б"}}
  ],
  2:[
    {n:1, s:"Архитектура программного обеспечения", t:"lec", room:"101", b:"корпус В", who:"Ковалёв А. А."},
    {n:2, s:"Компьютерные сети", t:"lab", room:"316", b:"корпус Б", who:"Сафина А. Р."},
    {n:3, s:"Английский язык", t:"prac", room:"507", b:"корпус А", who:"Никитина Е. П."}
  ],
  3:[
    {n:3, s:"Веб-разработка", t:"lec", room:"онлайн", b:"ссылка в уведомлении", who:"Морозов И. В.", online:true},
    {n:4, s:"Веб-разработка", t:"lab", room:"230", b:"корпус Б", who:"Морозов И. В."},
    {n:5, s:"Физическая культура", t:"pe", room:"Спорткомплекс", b:"зал 2", who:"Тихонов В. А."}
  ],
  4:[
    {n:1, s:"Базы данных", t:"lec", room:"305", b:"корпус А", who:"Лебедева О. И."},
    {n:2, s:"Архитектура программного обеспечения", t:"prac", room:"410", b:"корпус А", who:"Ковалёв А. А.", cancel:"Перенесено на субботу, 3 пара"},
    {n:3, s:"Компьютерные сети", t:"lec", room:"101", b:"корпус В", who:"Сафина А. Р."}
  ],
  5:[
    {n:2, s:"Проектная деятельность", t:"prac", room:"Коворкинг", b:"корпус Т, 2 этаж", who:"Гусев Р. О."},
    {n:3, s:"Английский язык", t:"prac", room:"507", b:"корпус А", who:"Никитина Е. П."},
    {n:4, s:"Физическая культура", t:"pe", room:"Спорткомплекс", b:"зал 2", who:"Тихонов В. А."}
  ],
  6:[
    {n:3, s:"Архитектура программного обеспечения", t:"prac", room:"410", b:"корпус А", who:"Ковалёв А. А.", moved:"Перенос с четверга, 2 пары"}
  ]
};

const CURRENT = [
  {s:"Базы данных", ctrl:"Экзамен", date:"2027-01-12", comps:[["Посещение",9,10],["Лабораторные работы",30,40],["Контрольные",18,20],["Экзамен",null,30]],
   todo:[{t:"ЛР № 6", d:"2026-11-14", pts:6}], status:"ok", hint:"Сдайте ЛР № 6 до 14 ноября — это ещё +6 баллов. На «хорошо» на экзамене хватит 19 из 30."},
  {s:"Теория вероятностей и мат. статистика", ctrl:"Экзамен", date:"2027-01-16", comps:[["Посещение",8,10],["Домашние задания",22,30],["Контрольные",11,30],["Экзамен",null,30]],
   todo:[{t:"пересдачу КР № 2", d:"2026-11-18", pts:11, where:"ауд. 412-А"}], status:"risk", hint:"КР № 2 написана на 4 из 15. Пересдача 18 ноября, ауд. 412-А. Без неё до допуска не хватает 9 баллов."},
  {s:"Архитектура программного обеспечения", ctrl:"Экзамен", date:"2027-01-21", comps:[["Посещение",10,10],["Курсовой проект",38,40],["Тесты",19,20],["Защита проекта",null,30]],
   finDate:"2026-12-02", status:"auto", hint:"Идёте на «отлично» автоматом: защитите проект 2 декабря хотя бы на 24 балла."},
  {s:"Компьютерные сети", ctrl:"Зачёт", date:"2026-12-23", comps:[["Посещение",9,10],["Лабораторные работы",45,60],["Итоговый тест",20,30]],
   status:"done", hint:"Зачёт уже набран. Его поставят в ведомость в зачётную неделю."},
  {s:"Веб-разработка", ctrl:"Диф. зачёт", date:"2026-12-24", comps:[["Посещение",7,10],["Лабораторные работы",40,60],["Финальный проект",null,30]],
   finDate:"2026-12-19", status:"ok", hint:"Финальный проект — до 19 декабря. Для «хорошо» нужно 29 баллов за проект."},
  {s:"Английский язык", ctrl:"Зачёт", date:"2026-12-22", comps:[["Посещение",10,10],["Задания",38,50],["Итоговый тест",null,40]],
   finDate:"2026-12-15", status:"ok", hint:"До зачёта осталось 13 баллов — итоговый тест 15 декабря."},
  {s:"Проектная деятельность", ctrl:"Зачёт", date:"2026-12-25", comps:[["Этапы проекта",30,60],["Демо-день",null,40]],
   todo:[{t:"прототип проекта", d:"2026-11-28", pts:15}], status:"ok", hint:"Следующий этап — прототип, сдача 28 ноября."},
  {s:"Физическая культура", ctrl:"Зачёт", date:"2026-12-21", comps:[["Посещения (из 24)",18,24],["Нормативы",null,76]],
   status:"ok", hint:"Осталось посетить 6 занятий. Нормативы — 7 декабря."}
];
const RECORD = {   // [дисциплина, форма контроля, итог по 100-балльной шкале]
  1:[["Математический анализ","Экзамен",84],["Алгебра и геометрия","Экзамен",93],["Программирование","Экзамен",96],["История России","Зачёт",78],["Английский язык","Зачёт",82],["Введение в профессию","Диф. зачёт",91]],
  2:[["Математический анализ","Экзамен",86],["Дискретная математика","Экзамен",92],["Алгоритмы и структуры данных","Экзамен",97],["Физика","Экзамен",79],["Английский язык","Зачёт",85],["Философия","Зачёт",74]],
  3:[["Объектно-ориентированное программирование","Экзамен",94],["Операционные системы","Экзамен",83],["Дифференциальные уравнения","Экзамен",81],["Экономика","Диф. зачёт",92],["Английский язык","Зачёт",88]],
  4:[["Архитектура ЭВМ","Экзамен",95],["Алгоритмы на графах","Экзамен",91],["Технологии программирования","Экзамен",98],["Безопасность жизнедеятельности","Зачёт",90],["Учебная практика","Диф. зачёт",96]]
};
// 100-балльная шкала: 91+ отлично, 76+ хорошо, 61+ удовлетворительно; у зачёта 61+ — «зачтено»
const markOf = (b, ctrl) => ctrl==="Зачёт" ? (b>=61 ? ["зачтено","m5"] : ["не зачтено","m2"])
  : b>=91 ? ["отлично","m5"] : b>=76 ? ["хорошо","m4"] : b>=61 ? ["удовл.","m3"] : ["неуд.","m2"];
const DEADLINES = [
  {d:"2026-11-14", t:"ЛР № 6 по базам данных", s:"Загрузить отчёт в курс"},
  {d:"2026-11-18", t:"Пересдача КР № 2 по ТВиМС", s:"10:10, ауд. 412-А"},
  {d:"2026-11-20", t:"Заявка на повышенную стипендию", s:"Деканат, онлайн"},
  {d:"2026-11-20", t:"Выбор темы курсового проекта", s:"Архитектура ПО"},
  {d:"2026-11-28", t:"Прототип — проектная деятельность", s:"Демо в коворкинге"},
  {d:"2026-12-02", t:"Защита курсового проекта", s:"Архитектура ПО"}
];
const CATALOG = [
  {id:"study", t:"Справка об обучении", d:"Подтверждает, что вы студент. Для СФР, работы родителей, банка.", sla:"Сразу", e:true, p:true, en:true},
  {id:"stip", t:"Справка о стипендии", d:"Размер выплат за выбранные месяцы.", sla:"1 рабочий день", e:true, p:true},
  {id:"army", t:"Справка для военкомата", d:"По форме № 26, с печатью вуза.", sla:"2 рабочих дня", e:false, p:true},
  {id:"acad", t:"Академическая справка", d:"Выписка оценок и часов — для перевода в другой вуз.", sla:"5 рабочих дней", e:false, p:true},
  {id:"aid", t:"Материальная помощь", d:"Заявление с подтверждающими документами.", sla:"До 10 дней", app:true,
    rules:"Опишите обстоятельства, по которым вы просите помощь. Укажите, когда они возникли и какие расходы связаны с обращением.", documents:"Подтверждение основания обращения. Например, для расходов подойдут квитанция или счёт."},
  {id:"plan", t:"Индивидуальный график", d:"Для спортсменов, работающих, по здоровью.", sla:"До 7 дней", app:true,
    rules:"Укажите период, занятия, которые придётся пропустить, и предложите даты отработки.", documents:"Подтверждение занятости в указанные даты: например, график работы или приглашение на спортивные сборы."},
  {id:"credit", t:"Перезачёт дисциплин", d:"Если предмет уже сдан в другом вузе или колледже.", sla:"До 14 дней", app:true,
    rules:"Перечислите уже пройденные дисциплины, часы или зачётные единицы и оценки. Укажите, какие дисциплины просите перезачесть.", documents:"Академическая справка или приложение к диплому с дисциплинами, оценками и объёмом занятий."},
  {id:"leave", t:"Академический отпуск", d:"Перед подачей лучше обсудить с методистом в чате.", sla:"До 10 дней", app:true,
    rules:"Укажите основание для отпуска и предполагаемые даты его начала и окончания.", documents:"Подтверждение обстоятельств и периода отсутствия. Вид документа зависит от основания отпуска; его можно уточнить у методиста."}
];
const STEPS = ["Подана","В работе","Готова","Получена"];
const DEFAULT_REQS = [
  {id:"З-2611-0482", t:"Справка об обучении", sub:"Для Социального фонда · электронная", step:2, date:"2026-11-06", doc:true, purpose:"Социальный фонд России"},
  {id:"З-2611-0517", t:"Индивидуальный график", sub:"Спортивные сборы 23–30 ноября", step:1, date:"2026-11-05", info:"На согласовании у заведующего кафедрой"},
  {id:"З-2610-0391", t:"Справка для военкомата", sub:"Форма № 26 · бумажная", step:3, date:"2026-10-24", info:"Выдана 28 октября в каб. 214"},
  {id:"З-2609-0233", t:"Справка об обучении", sub:"Банк · электронная", step:3, date:"2026-09-18", doc:true, purpose:"Банк", info:"Получена 18 сентября"},
  {id:"З-2609-0107", t:"Справка о стипендии", sub:"Июнь–август · электронная", step:3, date:"2026-09-04", info:"Получена 5 сентября"},
  {id:"З-2605-0451", t:"Материальная помощь", sub:"Заявление · онлайн", step:3, date:"2026-05-12", info:"Одобрено, выплата 6 000 ₽ в июне"}
];
const DEFAULT_NOTES = [
  {id:"session-published", k:"schedule", t:"Опубликовано расписание зимней сессии", p:"В разделе «Учёба» откройте вкладку «Сессия», чтобы посмотреть даты зачётов и экзаменов.", when:"18 ноября", go:"grades", imp:true},
  {id:"plan-applications", k:"dean", t:"Открыт приём заявлений на индивидуальный график", p:"Подготовьте даты и основание для изменения графика. Правила и список документов доступны в форме заявления.", when:"17 ноября", go:"requests", imp:true},
  {id:"n3", k:"deadline", t:"Срок сдачи лабораторной работы по базам данных", p:"Отчёт загружается в курс, срок 24 ноября, 23:59.", when:"вчера, 10:00", go:"grades"},
  {id:"n4", k:"docs", t:"Справка об обучении готова", p:"Электронная, с подписью. Её можно открыть и отправить.", when:"6 ноября", go:"requests"},
  {id:"n5", k:"dean", t:"Повышенная стипендия: приём заявок до 20 ноября", p:"Подготовьте подтверждения научных, спортивных или общественных достижений. Условия приёма уточните в деканате.", when:"5 ноября", go:"requests", imp:true},
  {id:"n6", k:"news", t:"Ярмарка стажировок 14 ноября", p:"Атриум корпуса А, 12:00–17:00. Будет 30 компаний, нужна регистрация.", when:"4 ноября"},
  {id:"n7", k:"dean", t:"Темы курсовых по архитектуре ПО", p:"Список на кафедре и в разделе «Учёба». Выбрать до 20 ноября.", when:"3 ноября", go:"grades"},
  {id:"n8", k:"security", t:"Новый вход: MacBook, Safari", p:"Если это были не вы — завершите сеанс в настройках.", when:"2 ноября", go:"settings"}
];
const DEFAULT_CHAT = [
  {me:true, t:"Здравствуйте! Подскажите, можно ли перезачесть английский из колледжа?", w:"3 ноя, 12:04"},
  {me:false, t:"Здравствуйте, Анна. Можно, если совпадает объём часов. Подайте заявление «Перезачёт дисциплин» и приложите скан диплома с приложением — я проверю за 2–3 дня.", w:"3 ноя, 14:31", who:"Ирина Волкова, методист"}
];
/* мессенджер: деканат хранит переписку в S.chat (как раньше), у остальных к примерам добавляются свои сообщения из S.chats */
const CHATS = [
  {id:"dean", n:"Деканат ИИТ", ini:"ИВ", role:"Ирина Волкова, методист · отвечает за 2–3 часа", unread:0,
    info:[["Кабинет","214, корпус Б"],["Приём","пн–чт 10:00–16:00, пт до 15:00"],["Обед","13:00–13:45"],["Телефон","Не указан"],["Почта","dekanat.iit@example.invalid"]],
    reply:"Получила, посмотрю и отвечу сегодня до 16:00."},
  {id:"curator", n:"Демо Куратор", ini:"ЛО", role:"куратор группы ПИ-31", unread:1,
    info:[["Кафедра","Программной инженерии, 228-Б"],["Часы","вт и чт 14:00–15:30"],["Почта","o.lebedeva@example.invalid"]],
    reply:"Хорошо, Анна, обсудим после пары.",
    msgs:[{me:false, t:"Анна, напоминаю: до пятницы сдать согласие на практику в деканат.", w:"12 ноя, 10:15"},
      {me:true, t:"Спасибо! Отнесу в четверг.", w:"12 ноя, 10:40"},
      {me:false, t:"В четверг в 15:40 собрание группы в 305-А, будет про распределение на практику.", w:"13 ноя, 18:02"}]},
  {id:"group", n:"ПИ-31 · группа", ini:"31", role:"24 участника", unread:3, group:true,
    info:[["Староста","Максим Орлов"],["Участники","24 студента и куратор"]],
    msgs:[{me:false, who:"Максим Орлов", t:"Ребята, ТВиМС завтра в 412, а не в 305!", w:"13 ноя, 20:11"},
      {me:false, who:"Дарья Ким", t:"Кто-нибудь скинет конспект последней лекции по БД?", w:"13 ноя, 21:03"},
      {me:false, who:"Илья Смирнов", t:"Скинул в папку группы, раздел «Неделя 11».", w:"13 ноя, 21:20"}]},
  {id:"petrov", n:"Петров Дмитрий Сергеевич", ini:"ПД", role:"преподаватель · теория вероятностей", unread:0,
    info:[["Кафедра","Высшей математики, 305-А"],["Консультации","ср 13:30–14:00"],["Почта","d.petrov@example.invalid"]],
    reply:"Принято. Посмотрю после проверки работ.",
    msgs:[{me:true, t:"Дмитрий Сергеевич, можно сдать КР № 2 на консультации в среду?", w:"10 ноя, 17:30"},
      {me:false, t:"Можно, приходите к 13:30. Захватите черновик.", w:"10 ноя, 19:05"}]},
  {id:"lib", n:"Библиотека", ini:"Б", role:"абонемент, корпус А · каб. 104", unread:1,
    info:[["Часы","пн–пт 9:00–19:00, сб до 15:00"],["Телефон","Не указан"]],
    reply:"Спасибо! Книга забронирована на 3 дня.",
    msgs:[{me:false, t:"«Базы данных» Дейта, которую вы бронировали, вернулась. Заберите до 18 ноября.", w:"14 ноя, 09:12"}]}
];
/* справочник для поиска в мессенджере: [id, кто, ФИО, чем занят, кафедра/группа, консультации/курс, логин почты].
   id "petrov" и "curator" совпадают с чатами выше: поиск открывает существующую переписку */
const PEOPLE = [
  ["petrov","teacher","Петров Дмитрий Сергеевич","теория вероятностей","Высшей математики, 305-А","ср 13:30–14:00","d.petrov"],
  ["curator","teacher","Демо Куратор","базы данных, куратор ПИ-31","Программной инженерии, 228-Б","вт и чт 14:00–15:30","o.lebedeva"],
  ["t-kovalev","teacher","Ковалёв Андрей Андреевич","архитектура программного обеспечения","Программной инженерии, 228-Б","пн 15:40–16:30","a.kovalev"],
  ["t-morozov","teacher","Морозов Игорь Викторович","веб-разработка","Информационных систем, 230-Б","пт 12:00–13:00","i.morozov"],
  ["t-safina","teacher","Сафина Алина Рашидовна","компьютерные сети","Информационных систем, 316-Б","ср 15:40–16:30","a.safina"],
  ["t-nikitina","teacher","Никитина Елена Павловна","английский язык","Иностранных языков, 507-А","чт 11:50–12:30","e.nikitina"],
  ["t-gusev","teacher","Гусев Роман Олегович","проектная деятельность","Программной инженерии, коворкинг Т","по записи в чате","r.gusev"],
  ["t-tikhonov","teacher","Тихонов Виктор Алексеевич","физическая культура","Физвоспитания, спорткомплекс","пн–пт 9:00–17:00","v.tikhonov"],
  ["s-orlov","student","Орлов Максим","ПИ-31, староста","ПИ-31","3 курс","m.orlov"],
  ["s-kim","student","Ким Дарья","ПИ-31","ПИ-31","3 курс","d.kim"],
  ["s-smirnov","student","Смирнов Илья","ПИ-31","ПИ-31","3 курс","i.smirnov"],
  ["s-belova","student","Белова Ксения","ПИ-31","ПИ-31","3 курс","k.belova"],
  ["s-akhmedov","student","Ахмедов Тимур","ПИ-32","ПИ-32","3 курс","t.akhmedov"],
  ["s-frolova","student","Фролова Вера","ИБ-21, информационная безопасность","ИБ-21","2 курс","v.frolova"],
  ["s-zaitsev","student","Зайцев Глеб","ПИ-41, наставник проектов","ПИ-41","4 курс","g.zaitsev"],
  ["s-nazarova","student","Назарова Алия","ПМ-31, студсовет ИИТ","ПМ-31","3 курс","a.nazarova"]
].map(([id,k,n,what,where,when,mail]) => ({id, k, n, ini:n.split(" ").slice(0,2).map(w=>w[0]).join(""),
  role:(k==="teacher" ? "преподаватель · " : "студент · ") + what,
  info: k==="teacher" ? [["Кафедра",where],["Консультации",when],["Почта",mail+"@example.invalid"]] : [["Группа",where],["Курс",when],["Институт","ИИТ"],["Почта",mail+"@student.example.invalid"]],
  reply: k==="teacher" ? "Добрый день. Посмотрю и отвечу после занятий." : "Привет! Я на паре, отвечу чуть позже."}));
const personChat = p => ({id:p.id, n:p.n, ini:p.ini, role:p.role, unread:0, info:p.info, reply:p.reply, msgs:[], person:p.k});

/* доска мероприятий: [id, через сколько дней, начало, конец, категория, название, место, организатор, совместно с, описание, уже идут] */
const EVENTS = [
  ["e1",2,"18:00","20:30","Карьера","Карьерный вечер: как попасть на стажировку в IT","Атриум, корпус А","Центр карьеры","Технопарк «Северный»","Выпускники и тимлиды расскажут, как проходят отборы, что смотреть в резюме и как готовиться к техническому интервью. После — разбор резюме один на один.",86],
  ["e2",3,"15:40","17:10","Наука","Семинар «ИИ в учебном процессе»","Ауд. 101, корпус В","Кафедра программной инженерии",null,"Открытый семинар кафедры: как языковые модели помогают в проектах и где заканчивается честная работа. Можно прийти с вопросом по курсовой.",42],
  ["e3",5,"10:00","19:00","Наука","Хакатон «Цифровой кампус»","Коворкинг, корпус Т","Студсовет ИИТ","Политех","Два дня, команды по 3–5 человек, задачи от служб вуза: навигация, расписание, столовая. Призы и баллы в портфолио для повышенной стипендии.",120],
  ["e4",6,"19:00","21:00","Культура","Осенний концерт студенческого оркестра","Актовый зал, корпус А","Дом культуры вуза",null,"Классика и саундтреки к играм. Вход по студенческому билету, гостям — по регистрации.",210],
  ["e5",8,"10:00","14:00","Спорт","Межвузовский турнир по волейболу","Спорткомплекс, зал 1","Спортклуб","Политех и Медуниверситет","Сборная вуза против команд двух университетов. Нужны болельщики и волонтёры на судейский стол.",64],
  ["e6",10,"09:00","14:00","Студжизнь","День донора","Медпункт, корпус Б","Профком","Городская служба крови","Накануне выспаться и позавтракать. Донорам — справка об освобождении от занятий на день.",58],
  ["e7",13,"12:00","17:00","Карьера","Ярмарка вакансий для старших курсов","Атриум, корпус А","Центр карьеры","30 компаний-партнёров","Стажировки, практика и первая работа. Возьмите распечатанное резюме, регистрация на месте.",174],
  ["e8",17,"18:30","20:30","Культура","Киноклуб: фильм об истории криптографии","Ауд. 305, корпус А","Киноклуб ИИТ",null,"Показ и обсуждение с преподавателем кафедры информационной безопасности.",37],
  ["e9",20,"10:00","18:00","Наука","Конференция молодых учёных «Информационные технологии»","Конгресс-холл, корпус В","Научное общество студентов","Агроуниверситет","Секции по ИИ, данным и разработке. Тезисы принимаются до конца месяца, лучшие доклады идут в сборник.",95]
].map(([id,dd,s,e,cat,t,place,org,joint,desc,base]) => ({id, d:addDays(dayStart(now()), dd), s, e, cat, t, place, org, joint, desc, base}));
const EV_CATS = [["all","Все"],["Наука","Наука"],["Карьера","Карьера"],["Культура","Культура"],["Спорт","Спорт"],["Студжизнь","Студжизнь"],["joint","Совместные"],["mine","Я иду"]];
const evKey = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const toMin = v => { const [h,m] = v.split(":").map(Number); return h*60+m; };
const evGoing = ev => window.lkMy.has("ev-"+ev.id);   // «Пойду» = мероприятие лежит в расписании; удалили там — пропало и здесь

const DEFAULT_DEVICES = [
  {id:"d1", n:"iPhone 15 · приложение", w:"сейчас", cur:true},
  {id:"d2", n:"MacBook · Safari", w:"2 ноября, 21:15"},
  {id:"d3", n:"Компьютерный класс 228-Б · Chrome", w:"вчера, 14:02"}
];
const UNIS = [
  {id:"green", n:"Зачётка", h:162, label:"Доска"},
  {id:"blue", n:"Политех", h:218, label:"Политех"},
  {id:"wine", n:"Медуниверситет", h:350, label:"Медвуз"},
  {id:"amber", n:"Агроуниверситет", h:32, label:"Аграрный"}
];

/* ===== состояние ===== */
const S = {
  view:"today",
  day:null,
  gradeTab:"now",
  sem:4,
  noteFilter:"all",
  inboxTab:"chat",     // уведомления: chat — мессенджер, notes — новости
  chatId:"dean", chatOpen:false, typing:null,
  chats: LS.get("chats", {}),
  chatRead: LS.get("chatRead", []),
  people: LS.get("people", []),   // с кем начата переписка через поиск
  msQ:"", msKind:"chats",          // поиск в мессенджере и вкладка: chats / teacher / student
  evFilter:"all",
  openSubj:{},
  infoTab:0,           // окно профиля: 0 основное, 1 личное, 2 контакты
  shown:{},            // какие скрытые поля открыты глазком
  reqs: LS.get("reqs", DEFAULT_REQS),
  read: LS.get("read", []),
  chat: LS.get("chat", DEFAULT_CHAT),
  devices: LS.get("devices", DEFAULT_DEVICES),
  tfa: LS.get("tfa", true),
  prefs: LS.get("prefs", {sched:true, dead:true, news:false, phone:false}),
  uni: LS.get("uni", "green"),
  authed: LS.get("authed", true)
};
S.people.forEach(id => { const p = PEOPLE.find(x=>x.id===id); if(p && !CHATS.some(c=>c.id===id)) CHATS.unshift(personChat(p)); });
const save = () => { LS.set("people",S.people); LS.set("chats",S.chats); LS.set("chatRead",S.chatRead); LS.set("reqs",S.reqs); LS.set("read",S.read); LS.set("chat",S.chat); LS.set("devices",S.devices); LS.set("tfa",S.tfa); LS.set("prefs",S.prefs); LS.set("uni",S.uni); LS.set("authed",S.authed); };
const unread = () => DEFAULT_NOTES.filter(n => !S.read.includes(n.id)).length;

/* шапка раздела: «назад» + заголовок (+ что-то справа) */
const BACK = `<button class="back" data-back aria-label="Назад"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14.5 6-6 6 6 6"/></svg></button>`;
const pageH = (t, right="") => `<div class="page-h">${BACK}<h1>${t}</h1>${right}</div>`;

/* ===== успеваемость: вычисления ===== */
const sumOf = c => c.comps.reduce((s,[,g]) => s + (g||0), 0);
function recordAvg(){
  const all = Object.values(RECORD).flat().map(r=>r[2]);
  return all.reduce((a,b)=>a+b,0)/all.length;
}

/* ===== рекомендации: собираются из баллов, сроков и посещаемости предмета ===== */
const fmtD = d => { const x = new Date(d), t = now(); t.setHours(0,0,0,0); const n = Math.round((x - t)/864e5);
  return n===0 ? "сегодня" : n===1 ? "завтра" : `${x.getDate()} ${MONS[x.getMonth()]}`; };
function recsFor(c){
  const sum = sumOf(c), out = [], t0 = now(); t0.setHours(0,0,0,0);
  const exam = c.ctrl!=="Зачёт", fin = c.comps.find(x=>x[1]==null);
  const ticks = exam ? [[61,"«удовлетворительно»"],[76,"«хорошо»"],[91,"«отлично»"]] : [[61,"зачёта"]];
  (c.todo||[]).forEach(t => { const late = new Date(t.d) < t0;
    out.push({ic: late?"alert":"clock", t: late ? `Срок «${t.t}» прошёл — договоритесь с преподавателем о сдаче, иначе потеряете до ${t.pts} баллов.`
      : `Сдайте ${t.t} до ${fmtD(t.d)}${t.where?`, ${t.where}`:""} — это до +${t.pts} баллов.`}); });
  c.comps.filter(([n,g,m]) => g!=null && g/m < .7).forEach(([n,g,m]) => out.push({ic:"alert",
    t: n==="Посещение" ? `Пропущено ${m-g} из ${m} занятий — посещение даёт баллы, не пропускайте оставшиеся.`
      : `«${n}»: ${g} из ${m} (${Math.round(g/m*100)} %). Спросите преподавателя о доработке — это самый быстрый резерв баллов.`}));
  const att = c.comps.find(x=>x[0]==="Посещение");
  if(att && att[1]!=null && att[1] < att[2] && att[1]/att[2] >= .7) out.push({ic:"user", t:`Посещение ${att[1]} из ${att[2]}: каждое следующее занятие — это ещё балл к итогу.`});
  const next = ticks.find(([v]) => v > sum);
  if(!next) out.push({ic:"check", t: exam ? "Баллов уже хватает на «отлично» — держите темп до конца семестра." : "Зачёт уже набран — осталось не пропускать до зачётной недели."});
  else if(fin){
    const need = next[0] - sum, when = c.finDate ? ` (${fmtD(c.finDate)})` : "";
    if(need <= fin[2]){
      out.push({ic:"flag", t:`Для ${next[1]} на «${fin[0]}»${when} нужно ${need} из ${fin[2]}.`});
      const up = ticks.find(([v]) => v > next[0]);
      if(up && up[0]-sum <= fin[2]) out.push({ic:"grades", t:`До ${up[1]} — ${up[0]-sum} из ${fin[2]}: реально, если подготовиться заранее.`});
    } else out.push({ic:"alert", t:`Даже максимум за «${fin[0]}» не даст ${next[1]}: не хватит ${need - fin[2]} баллов. Добирайте текущими работами.`});
  } else out.push({ic:"flag", t:`До ${next[1]} не хватает ${next[0]-sum} баллов — спросите о дополнительных заданиях.`});
  return out.slice(0, 4);
}

function subjCard(c, i){
  const sum = sumOf(c);
  const open = S.openSubj[i];
  const isExam = c.ctrl!=="Зачёт";
  const ticks = isExam ? [[61,"61"],[76,"76"],[91,"91"]] : [[61,"61 · зачёт"]];
  const left = c.comps.filter(x=>x[1]==null).reduce((s,x)=>s+x[2],0);
  const recs = recsFor(c);
  return `<article class="subj ${c.status==="risk"?"risk":""} ${open?"open":""}">
    <button class="subj-h" data-action="subj" data-i="${i}" aria-expanded="${!!open}">
      <div class="top"><div class="row" style="gap:8px;min-width:0;flex-wrap:wrap"><h3>${esc(c.s)}</h3><span class="chip ctrl">${c.ctrl}</span>${c.status==="risk"?'<span class="chip alert">Нужно внимание</span>':""}</div>
        <div class="pts">${sum}<small> / 100</small></div></div>
      <div class="scale" aria-label="${sum} из 100 баллов"><div class="track"><div class="fill" style="width:${sum}%"></div></div>
        ${ticks.map(([v,l])=>`<span class="tick" style="left:${v}%"></span><span class="tl" style="left:${v}%">${l}</span>`).join("")}</div>
      <span class="subj-chev">${ic("arrow","i s")}</span>
    </button>
    <div class="subj-more"><div>
      <div class="comps">${c.comps.map(([n,g,m])=>`<div class="comp"><span class="muted">${n}</span><span class="v">${g==null?"—":g} / ${m}</span></div>`).join("")}
        <div class="comp"><span class="muted">Ещё можно набрать</span><span class="v">${left}</span></div>
        <div class="comp"><span class="muted">${isExam?c.ctrl:"Зачёт"}</span><span class="v">${new Date(c.date).toLocaleDateString("ru-RU",{day:"numeric",month:"long"})}</span></div></div>
      <div class="recs"><b>Рекомендации</b><ul>${recs.map(r=>`<li>${ic(r.ic,"i s")}<span>${esc(r.t)}</span></li>`).join("")}</ul></div>
    </div></div>
  </article>`;
}

// стипендия только у бюджетников; прогноз по текущим баллам
function scholarship(){
  const risk = CURRENT.filter(c=>c.status==="risk"), low = CURRENT.filter(c=>c.ctrl!=="Зачёт" && sumOf(c) + c.comps.filter(x=>x[1]==null).reduce((s,x)=>s+x[2],0) < 76);
  const bad = [...new Set([...risk, ...low])];
  return `<section class="card"><div class="card-h"><h2>Стипендия</h2><span class="chip ok">Назначена</span></div>
    <div class="kv"><dt>Вид</dt><dd>Академическая, «хорошо» и «отлично»</dd><dt>Размер</dt><dd class="mono">3 400 ₽ в месяц</dd><dt>Условие</dt><dd>Сдать сессию без троек и в срок</dd>
      <dt>Прогноз</dt><dd>${bad.length ? `<span style="color:var(--alert)">Под угрозой: ${bad.map(c=>esc(c.s)).join(", ")}</span>` : "Сохраняется, если сдать сессию по текущему темпу"}</dd></div>
  </section>`;
}
/* ===== рейтинг и посещаемость ===== */
function ratingRing(){
  const all = Object.values(RECORD).flat(), avg = Math.round(recordAvg()), C = 2*Math.PI*52;
  const cnt = k => all.filter(([,c,b])=>markOf(b,c)[0]===k).length;
  const parts = [["отлично","m5"],["хорошо","m4"],["удовл.","m3"],["зачтено","m5"]].map(([k,m])=>[k,m,cnt(k)]).filter(x=>x[2]);
  return `<section class="card gr-ring" aria-label="Средний балл ${avg} из 100">
    <div class="ring"><svg viewBox="0 0 132 132" aria-hidden="true"><defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--h3)"/><stop offset="1" stop-color="var(--h1)"/></linearGradient></defs>
      <circle cx="66" cy="66" r="52" class="rt"/><circle cx="66" cy="66" r="52" class="ra" style="--c:${C.toFixed(1)};--o:${(C*(1-avg/100)).toFixed(1)}" stroke-dasharray="${C.toFixed(1)}" stroke-dashoffset="${(C*(1-avg/100)).toFixed(1)}"/></svg>
      <div class="ring-c"><b>${avg}</b><span>из 100</span></div></div>
    <div class="ring-side"><div><small>Средний балл зачётки</small><b>${markOf(avg,"Экзамен")[0]}</b></div>
      <div class="ring-marks">${parts.map(([k,m,n])=>`<span><i class="mark-cell ${m}">${n}</i>${k}</span>`).join("")}</div></div>
  </section>`;
}
function attendance(){
  const ATT = CURRENT.map(c=>c.comps.find(x=>x[0]==="Посещение")).filter(Boolean);
  const got = ATT.reduce((n,x)=>n+x[1],0), all = ATT.reduce((n,x)=>n+x[2],0), missed = all - got;
  const start = new Date(2026,7,31), end = new Date(2026,11,27), t0 = now(); t0.setHours(0,0,0,0);
  const HOL = ["2026-11-04"], days = [];
  for(let d = new Date(start); d < end; d.setDate(d.getDate()+1)){ const wd = d.getDay(); if(wd===0) continue;
    const iso = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
    days.push({d:new Date(d), iso, n: d < new Date(2026,8,1) || HOL.includes(iso) ? 0 : (SCHEDULE[wd]||[]).length, past: d <= t0, miss:0}); }
  // пропуски раскладываются по прошедшим дням детерминированно, чтобы сумма совпала с баллами за посещение
  let seed = 7; const rnd = () => (seed = (seed*16807) % 2147483647) / 2147483647;
  const past = days.filter(x=>x.past && x.n); for(let k=0; k<missed && past.length; ){ const x = past[Math.floor(rnd()*past.length)]; if(x.miss < x.n){ x.miss++; k++; } }
  const weeks = Math.ceil(days.length/6), MN = ["сен","окт","ноя","дек"];
  const cells = days.map(x=>{ const lvl = !x.n ? "e" : !x.past ? "f" : x.miss===x.n ? "m" : x.miss ? "p" : "a" + Math.min(4, x.n);
    const lab = `${x.d.getDate()} ${MONS[x.d.getMonth()]}: ${!x.n?"занятий нет":!x.past?`${x.n} ${plural(x.n,"пара","пары","пар")} впереди`:`${x.n-x.miss} из ${x.n} ${plural(x.n,"пары","пар","пар")}`}`;
    return `<i class="${lvl}" title="${lab}"></i>`; }).join("");
  const monthCols = [0,1,2,3].map(m=>{ const first = days.findIndex(x=>x.d.getMonth()===8+m && x.d.getDate()>=1); return `<span style="grid-column:${Math.floor(first/6)+1}">${MN[m]}</span>`; }).join("");
  return `<section class="card gr-att"><div class="card-h"><h2>Посещаемость</h2><b class="gr-pct">${Math.round(got/all*100)} %</b></div>
    <div class="hm-wrap" style="--w:${weeks}"><div class="hm-m" style="--w:${weeks}">${monthCols}</div>
      <div class="hm" style="--w:${weeks}" role="img" aria-label="Посещаемость по дням: пропущено ${missed} из ${all} занятий">${cells}</div></div>
    <div class="hm-leg"><span>Пропущено ${missed} из ${all} занятий</span><span class="hm-key"><i class="m"></i>пропуск<i class="p"></i>частично<i class="a3"></i>все пары</span></div>
  </section>`;
}

function vGrades(){
  const avg = recordAvg();
  const risks = CURRENT.filter(c=>c.status==="risk").length;
  const auto = CURRENT.filter(c=>c.status==="auto"||c.status==="done").length;
  const sessionDays = daysTo("2026-12-21");
  let body;
  if(S.gradeTab==="now"){
    body = `<div style="display:grid;gap:10px">${CURRENT.map(subjCard).join("")}</div>`;
  } else if(S.gradeTab==="session"){
    const exams = CURRENT.slice().sort((a,b)=>a.date.localeCompare(b.date));
    body = `<section class="card">
      <div class="session"><span class="big">${Math.max(0,sessionDays)}</span><div><b>${plural(sessionDays,"день","дня","дней")} до зачётной недели</b></div></div>
      <div class="timeline">${exams.map(c=>{ const d=new Date(c.date); return `<div class="r"><span class="mono small">${d.getDate()} ${MONS[d.getMonth()]}, ${DOW[d.getDay()]}</span><span style="min-width:0">${esc(c.s)}</span><span class="chip ${c.ctrl==="Экзамен"?"accent":""}">${c.ctrl}</span></div>`; }).join("")}</div>
    </section>
    ${STUDENT.funding==="budget" ? scholarship() : ""}`;
  } else {
    const rows = RECORD[S.sem];
    body = `<div class="seg" role="group" aria-label="Семестр">${[1,2,3,4].map(n=>`<button data-action="sem" data-n="${n}" aria-pressed="${S.sem===n}">${n} семестр</button>`).join("")}</div>
      <section class="card" style="overflow-x:auto"><table class="record"><thead><tr><th>Дисциплина</th><th>Форма</th><th>Баллы</th></tr></thead><tbody>
      ${rows.map(([n,f,b])=>{ const [w,m] = markOf(b,f); return `<tr><td>${esc(n)}</td><td class="muted">${f}</td><td class="rec-b"><span class="mark-cell ${m}">${b}</span><span class="muted small">${w}</span></td></tr>`; }).join("")}
      </tbody></table></section>`;
  }
  return `<div class="view">
    ${pageH("Успеваемость")}
    <h2 class="gr-title">Рейтинг</h2>
    <div class="gr-top">${ratingRing()}${attendance()}</div>
    <p class="gr-sem">5 семестр · 2026/27</p>
    <div class="seg gr-seg" role="group" aria-label="Раздел">
      <button data-action="gtab" data-t="now" aria-pressed="${S.gradeTab==="now"}">Баллы</button>
      <button data-action="gtab" data-t="session" aria-pressed="${S.gradeTab==="session"}">Сессия</button>
      <button data-action="gtab" data-t="record" aria-pressed="${S.gradeTab==="record"}">Зачётка</button>
    </div>
    ${body}
  </div>`;
}

function reqCard(r){
  const steps = STEPS.map((_,i)=>`<i class="${i<r.step?"on":i===r.step?(r.step===3||r.step===2?"on":"cur"):""}"></i>`).join("");
  const labels = STEPS.map((s,i)=>`<span class="${i===r.step?"on":""}">${s}</span>`).join("");
  const stChip = r.step===2 ? '<span class="chip ok">Готова</span>' : r.step===3 ? '<span class="chip">Получена</span>' : r.step===1 ? '<span class="chip warn">В работе</span>' : '<span class="chip accent">Подана</span>';
  return `<article class="req">
    <div class="top"><div style="min-width:0"><h3>${esc(r.t)}</h3><p class="muted small">${esc(r.sub)}</p></div>${stChip}</div>
    <div style="display:grid;gap:6px"><div class="steps">${steps}</div><div class="steplabels">${labels}</div></div>
    <div class="row small"><span class="grow muted">№ <span class="mono">${r.id}</span> · от ${fmtDate(new Date(r.date))}</span></div>
    ${r.info?`<p class="small">${esc(r.info)}</p>`:""}
    ${r.doc&&r.step>=2?`<div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn sm" data-action="doc" data-id="${r.id}">${ic("doc","i s")}Открыть справку</button><button class="btn sm ghost" data-action="copylink" data-id="${r.id}">Скопировать код проверки</button></div>`:""}
  </article>`;
}
const kindOf = r => (CATALOG.find(c=>c.t===r.t)||{}).app ? "app" : "cert";
const PICK = {
  cert: {title:"Заказ справки", q:"Найти справку", btn:"Заказать справку", sub:"Об обучении, о стипендии, для военкомата"},
  app:  {title:"Подать заявление", q:"Найти заявление", btn:"Подать заявление", sub:"Матпомощь, график, перезачёт, отпуск"},
  archive: {title:"Архив", q:"Найти в архиве", btn:"Архив", sub:"Ранее выданные справки и решения"}
};
function vRequests(){
  const active = S.reqs.filter(r=>r.step<3), done = S.reqs.filter(r=>r.step>=3);
  const act = (k, i) => `<button class="docs-act ${k==="cert"?"main":""}" data-action="picker" data-k="${k}">${ic(i,"i")}<span class="grow"><b>${PICK[k].btn}</b><small>${PICK[k].sub}</small></span>${k==="archive"&&done.length?`<span class="chip">${done.length}</span>`:""}${ic("arrow","i s")}</button>`;
  return `<div class="view">
    ${pageH("Документы")}
    <div class="docs-grid">
      <div class="docs-acts">${act("cert","doc")}${act("app","requests")}${act("archive","clock")}</div>
      <section class="docs-mine"><div class="card-h"><h2>Мои заявки</h2><span class="muted small">${active.length} ${plural(active.length,"активная","активных","активных")}</span></div>
        <div style="display:grid;gap:10px">${active.map(reqCard).join("") || `<div class="card empty">Активных заявок нет. Закажите справку — электронная готова за минуту.</div>`}</div></section>
    </div>
  </div>`;
}

/* ===== окно выбора: кнопка «перетекает» в стеклянное окно по центру ===== */
const SRCH = '<svg class="i s" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>';
function applicationGuide(c) {
  const sections = [["rules", "Правила заполнения", c.rules], ["documents", "Требуемые документы", c.documents]];
  const links = sections.map(([key, title]) => {
    const id = `guide-${c.id}-${key}`;
    return `<a href="#${id}" data-action="guide" aria-controls="${id}" aria-expanded="false">${title}</a>`;
  }).join("");
  const panels = sections.map(([key, title, body]) =>
    `<section id="guide-${c.id}-${key}" hidden><b>${title}</b><p>${body}</p><small>Памятка для учебного примера.</small></section>`
  ).join("");
  return `<div class="application-guide"><div class="guide-links">${links}</div>${panels}</div>`;
}
function pickItems(k){
  if(k==="archive") return S.reqs.filter(r=>r.step>=3).map(r=>({id:r.id, t:r.t, d:`${r.sub} · № ${r.id}`, k:`${r.t} ${r.sub} ${r.id}`, body: reqCard(r)}));
  return CATALOG.filter(c=>!!c.app === (k==="app")).map(c=>({id:c.id, t:c.t, d:`${c.d}`, sla:c.sla, k:`${c.t} ${c.d}`,
    body:`<form class="form gm-form" data-id="${c.id}">${orderFields(c)}
      <div class="kv small" style="padding:12px;border-radius:12px;background:var(--surface-2)"><dt>Срок</dt><dd>${c.sla}</dd><dt>Данные</dt><dd>${STUDENT.fio}, ${STUDENT.group}</dd></div>
      ${c.app ? applicationGuide(c) : ""}
      <p class="err" hidden></p><button class="btn block" type="submit">${c.app?"Подать заявление":"Заказать справку"}</button></form>`}));
}
function openPicker(k, openId){
  const from = document.querySelector(`[data-action="picker"][data-k="${k}"]`), P = PICK[k], list = pickItems(k);
  const root = document.getElementById("sheetRoot");
  root.innerHTML = `<div class="gm-wrap" data-action="closesheet"><div class="gm glass" role="dialog" aria-modal="true" aria-label="${P.title}" data-k="${k}">
    <div class="gm-in">
      <div class="gm-h"><h2>${P.title}</h2><button class="iconbtn" data-action="closesheet" aria-label="Закрыть">${ic("close","i s")}</button></div>
      <label class="gm-q">${SRCH}<input id="gmQ" type="search" placeholder="${P.q}" autocomplete="off" aria-label="${P.q}"></label>
      <div class="gm-list" id="gmList">${list.map(it=>`<div class="gm-it" data-id="${it.id}" data-k="${esc(it.k.toLowerCase())}">
          <button class="gm-row" data-action="gmopen" data-id="${it.id}" aria-expanded="false"><span class="chev">${ic("arrow","i s")}</span><span class="grow"><b>${esc(it.t)}</b><small>${esc(it.d)}</small></span>${it.sla?`<span class="chip ${it.sla==="Сразу"?"mark":""}">${it.sla}</span>`:""}</button>
          <div class="gm-body"><div>${it.body}</div></div></div>`).join("") || ""}
        <p class="gm-empty muted" ${list.length?"hidden":""}>${k==="archive"?"В архиве пока пусто.":"Ничего не нашлось."} <button class="link" data-go="inbox" data-tab="chat">Спросить методиста</button></p></div>
    </div></div></div>`;
  const gm = root.querySelector(".gm");
  morph(gm, from, false);
  if(openId) gmToggle(openId, true);
  setTimeout(()=>root.querySelector(openId ? `.gm-it[data-id="${openId}"] select, .gm-it[data-id="${openId}"] textarea` : "#gmQ")?.focus({preventScroll:true}), 60);
}
// FLIP: окно стартует с размеров и места кнопки и пружинит в центр; закрытие — обратно в кнопку
function morph(gm, from, back){
  const still = matchMedia("(prefers-reduced-motion: reduce)").matches || document.documentElement.classList.contains("calm");
  const wrap = gm.parentElement;
  if(!from || !from.isConnected || still){
    const a = gm.animate([{opacity:0, transform:"scale(.96)"},{opacity:1, transform:"none"}], {duration: still ? 120 : 220, easing:"ease-out", direction: back?"reverse":"normal", fill:"both"});
    wrap.animate([{opacity:0},{opacity:1}], {duration:200, direction: back?"reverse":"normal", fill:"both"});
    return a.finished;
  }
  const f = from.getBoundingClientRect(), t = gm.getBoundingClientRect();
  const dx = (f.left + f.width/2) - (t.left + t.width/2), dy = (f.top + f.height/2) - (t.top + t.height/2);
  const start = {transform:`translate(${dx}px,${dy}px) scale(${f.width/t.width},${f.height/t.height})`, borderRadius:"999px"}, end = {transform:"none", borderRadius:"32px"};
  from.style.visibility = "hidden";
  const o = {duration: back ? 380 : 620, easing: back ? "cubic-bezier(.5,0,.75,0)" : "cubic-bezier(.2,1.15,.35,1)", fill:"both"};
  const a = gm.animate(back ? [end, start] : [start, end], o);
  gm.querySelector(".gm-in").animate(back ? [{opacity:1},{opacity:0, offset:.4},{opacity:0}] : [{opacity:0},{opacity:0, offset:.35},{opacity:1}], o);
  wrap.animate([{backgroundColor:"transparent", backdropFilter:"blur(0)"},{}], {duration: o.duration, direction: back?"reverse":"normal", fill:"both"});
  if(!back){ a.finished.then(()=>{ from.style.visibility = ""; }); setTimeout(()=>{ from.style.visibility = ""; }, o.duration + 100); }
  return a.finished.then(()=>{ if(back) from.style.visibility = ""; });
}
function gmToggle(id, open){
  document.querySelectorAll("#gmList .gm-it").forEach(it=>{
    const on = it.dataset.id===id && (open ?? !it.classList.contains("open"));
    it.classList.toggle("open", on); it.querySelector(".gm-row").setAttribute("aria-expanded", on);
    if(on) setTimeout(()=>it.scrollIntoView({block:"nearest", behavior:"smooth"}), 260);
  });
}

const NOTE_ICON = {schedule:"schedule", deadline:"clock", docs:"doc", dean:"flag", news:"news", security:"shield"};
function vInbox(){
  const f = S.noteFilter;
  const list = DEFAULT_NOTES.filter(n => f==="all" ? true : f==="imp" ? n.imp : f==="schedule" ? n.k==="schedule" : f==="deadline" ? n.k==="deadline"||n.k==="dean" : n.k==="news"||n.k==="docs"||n.k==="security");
  const notesHtml = `<div class="row" style="gap:8px"><div class="seg grow" role="group" aria-label="Фильтр">${[["all","Все"],["imp","Важное"],["schedule","Расписание"],["deadline","Деканат"],["other","Прочее"]].map(([k,n])=>`<button data-action="nf" data-k="${k}" aria-pressed="${f===k}">${n}</button>`).join("")}</div></div>
    <section class="card"><div class="card-h"><h2>${list.length} ${plural(list.length,"уведомление","уведомления","уведомлений")}</h2>${unread()?`<button class="link" data-action="readall">Прочитать все</button>`:""}</div>
    <div class="list">${list.map(n=>{ const r=S.read.includes(n.id); return `<button class="note-item k-${n.k} ${r?"read":""}" data-action="note" data-id="${n.id}"><span class="ic">${ic(NOTE_ICON[n.k],"i s")}</span><span style="min-width:0"><h3>${r?"":'<span class="unread-dot"></span>'}${esc(n.t)}</h3><p>${esc(n.p)}</p><p class="small" style="margin-top:4px">${esc(n.when)}${n.imp?' · <span style="color:var(--alert);font-weight:600">важно</span>':""}</p></span></button>`; }).join("") || '<div class="empty">Здесь пока пусто.</div>'}</div></section>`;
  return `<div class="view">
    ${pageH("Уведомления")}
    <div class="seg ms-seg" role="tablist" aria-label="Раздел">
      <button role="tab" data-action="itab" data-t="chat" aria-pressed="${S.inboxTab==="chat"}" aria-selected="${S.inboxTab==="chat"}">Мессенджер${chatUnread()?`<span class="ms-badge">${chatUnread()}</span>`:""}</button>
      <button role="tab" data-action="itab" data-t="notes" aria-pressed="${S.inboxTab==="notes"}" aria-selected="${S.inboxTab==="notes"}">Новости${unread()?`<span class="ms-badge">${unread()}</span>`:""}</button>
      <button role="tab" data-action="itab" data-t="events" aria-pressed="${S.inboxTab==="events"}" aria-selected="${S.inboxTab==="events"}">Мероприятия</button>
    </div>
    ${S.inboxTab==="notes"?notesHtml:S.inboxTab==="events"?vEvents():vMessenger()}
  </div>`;
}

const chatMsgs = id => id==="dean" ? S.chat : CHATS.find(c=>c.id===id).msgs.concat(S.chats[id]||[]);
const chatUnreadOf = c => S.chatRead.includes(c.id) ? 0 : c.unread;
const chatUnread = () => CHATS.reduce((n,c)=>n+chatUnreadOf(c), 0);
const stamp = () => { const d = now(); return `${d.getDate()} ${MONS[d.getMonth()]}, ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`; };
// в списке: сегодня — время, раньше — дата
const shortW = w => { const [day, time] = w.split(", "), d = now(); return day === `${d.getDate()} ${MONS[d.getMonth()]}` ? time : day; };
const ICO = {
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.01"/>',
  clip:'<path d="M20 11.5 12.4 19a5 5 0 0 1-7.1-7.1l8-8a3.4 3.4 0 0 1 4.8 4.8l-8 8a1.7 1.7 0 0 1-2.4-2.4l7.3-7.3"/>',
  send:'<path d="M4.5 12 20 4.5 15.5 20l-3-6.5z"/><path d="m12.5 13.5 7.5-9"/>',
  back:'<path d="m14.5 6-6 6 6 6"/>'
};
const svg = p => `<svg viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
/* список слева: поиск по чатам и справочнику людей. При вводе перерисовывается только #msItems, чтобы поле не теряло фокус */
const nrm = v => String(v).toLowerCase().replace(/ё/g,"е");
function chatRow(x){
  const m = chatMsgs(x.id), last = m[m.length-1], u = chatUnreadOf(x);
  return `<button class="ms-it ${x.id===S.chatId?"on":""}" data-action="chat" data-id="${x.id}" aria-current="${x.id===S.chatId}">
      <span class="avatar ${x.group?"grp":""}">${x.ini}</span>
      <span class="ms-txt"><span class="ms-top"><b>${esc(x.n)}</b><time>${last?shortW(last.w):""}</time></span>
        <span class="ms-top"><small>${last?(last.me?"Вы: ":last.who?esc(last.who.split(" ")[0])+": ":"")+esc(last.t||last.file||""):"Новый чат"}</small>${u?`<span class="ms-badge">${u}</span>`:""}</span></span></button>`;
}
const personRow = p => `<button class="ms-it ms-person" data-action="person" data-id="${p.id}">
      <span class="avatar ${p.k}">${p.ini}</span>
      <span class="ms-txt"><span class="ms-top"><b>${esc(p.n)}</b></span><span class="ms-top"><small>${esc(p.role)}</small></span></span>
      <span class="ms-go">${CHATS.some(c=>c.id===p.id)?"Открыть":"Написать"}</span></button>`;
// раскладка: «rbv» → «ким»; слово от 4 букв ищется по основе («сеть» находит «сети», «петрову» — «Петров»)
const EN_KB = "qwertyuiop[]asdfghjkl;'zxcvbnm,.`", RU_KB = "йцукенгшщзхъфывапролджэячсмитьбюё";
const toRu = v => [...v].map(c => { const i = EN_KB.indexOf(c); return i < 0 ? c : RU_KB[i]; }).join("");
const stem = w => w.length >= 4 ? w.slice(0, w.length - (w.length > 5 ? 2 : 1)) : w;
function matcher(raw){
  const q = nrm(raw).trim();
  if(!q) return () => true;
  const variants = [q, toRu(q)].filter((v,i,a) => a.indexOf(v) === i).map(v => v.split(/\s+/).map(stem));
  return x => { const hay = nrm([x.n, x.role, ...(x.info||[]).map(r=>r[1])].join(" ")); return variants.some(ws => ws.every(w => hay.includes(w))); };
}
function msItems(){
  const q = nrm(S.msQ).trim(), hit = matcher(S.msQ);
  if(S.msKind !== "chats"){
    const ppl = PEOPLE.filter(p => p.k===S.msKind && hit(p));
    return ppl.map(personRow).join("") || '<p class="ms-empty">Никого не нашли. Попробуйте фамилию или группу.</p>';
  }
  const chats = CHATS.filter(hit), ppl = q ? PEOPLE.filter(p => !CHATS.some(c=>c.id===p.id) && hit(p)) : [];
  return chats.map(chatRow).join("") + (ppl.length ? `<p class="ms-sec">Люди в вузе</p>${ppl.map(personRow).join("")}` : "")
    || '<p class="ms-empty">Ничего не нашли. Поищите среди преподавателей и студентов.</p>';
}
function vMessenger(){
  const c = CHATS.find(x=>x.id===S.chatId), msgs = chatMsgs(c.id);
  const list = `<label class="ms-search">${SRCH}<input id="msQ" type="search" value="${esc(S.msQ)}" placeholder="Поиск людей и чатов" autocomplete="off" aria-label="Поиск преподавателей, студентов и чатов"></label>
      <div class="ms-kinds" role="tablist" aria-label="Кого искать">${[["chats","Чаты"],["teacher","Преподаватели"],["student","Студенты"]].map(([k,n])=>`<button role="tab" data-action="mskind" data-k="${k}" aria-selected="${S.msKind===k}">${n}</button>`).join("")}</div>
      <div class="ms-items" id="msItems">${msItems()}</div>`;
  let prevDay = "";
  const bubbles = msgs.map(m=>{ const day = m.w.split(", ")[0], sep = day!==prevDay ? `<div class="ms-day"><span>${day===shortW(m.w)?day:"Сегодня"}</span></div>` : ""; prevDay = day;
    return sep + `<div class="msg ${m.me?"me":"them"}">${!m.me&&c.group&&m.who?`<b class="ms-who">${esc(m.who)}</b>`:""}${m.file?`<span class="ms-file">${svg(ICO.clip)}${esc(m.file)}</span>`:""}${m.t?esc(m.t):""}<small>${esc(m.w.split(", ")[1]||m.w)}</small></div>`; }).join("");
  return `<div class="ms" data-open="${S.chatOpen?1:0}">
    <nav class="ms-list" aria-label="Чаты и поиск людей">${list}</nav>
    <section class="ms-chat" aria-label="Чат: ${esc(c.n)}">
      <header class="ms-h">
        <button class="ms-ib ms-back" data-action="chatback" aria-label="К списку чатов">${svg(ICO.back)}</button>
        <span class="avatar ${c.group?"grp":""}">${c.ini}</span>
        <span class="ms-name"><b>${esc(c.n)}</b><small>${esc(c.role)}</small></span>
        <button class="ms-ib" data-action="chatinfo" aria-label="О контакте">${svg(ICO.info)}</button>
      </header>
      ${c.id==="dean"?`<div class="topics ms-topics">${["Справка","Пересдача","Стипендия","Общежитие","Перевод"].map(t=>`<button data-action="topic" data-t="${t}">${t}</button>`).join("")}</div>`:""}
      <div class="chat ms-msgs" id="chat" aria-live="polite">${bubbles || `<p class="ms-hello"><span class="avatar">${c.ini}</span>Это начало переписки с ${esc(c.n)}.<br>Напишите первое сообщение.</p>`}${S.typing===c.id?`<div class="msg them typing" aria-label="Печатает"><i></i><i></i><i></i></div>`:""}</div>
      <form class="ms-comp" id="composer">
        <label class="ms-ib ms-att" title="Прикрепить файл"><input type="file" id="chatFile" class="sr" aria-label="Прикрепить файл">${svg(ICO.clip)}</label>
        <input id="chatInput" placeholder="${c.id==="dean"?"Напишите вопрос деканату":"Сообщение"}" autocomplete="off" aria-label="Сообщение">
        <button class="ms-ib ms-send" type="submit" aria-label="Отправить">${svg(ICO.send)}</button>
      </form>
    </section>
  </div>`;
}
function sendChat(msg){
  const id = S.chatId, c = CHATS.find(x=>x.id===id);
  if(id==="dean") S.chat.push(msg); else (S.chats[id] = S.chats[id] || []).push(msg);
  save(); render();
  if(!c.reply || S.typing) return;
  setTimeout(()=>{ S.typing = id; if(S.view==="inbox") render(); }, 600);
  setTimeout(()=>{ S.typing = null; const r = {me:false, t:c.reply, w:stamp(), who:c.role.split(" · ")[0]};
    if(id==="dean") S.chat.push(r); else (S.chats[id] = S.chats[id] || []).push(r);
    save(); if(S.view==="inbox") render(); if(S.view!=="inbox" || S.chatId!==id) toast(`${c.n}: новое сообщение`); }, 2400);
}

/* ===== доска мероприятий ===== */
function evCard(ev, hero){
  const go = evGoing(ev), n = ev.base + (go?1:0), dd = daysTo(ev.d);
  return `<article class="evb ${hero?"hero":""} ${go?"going":""}">
    <div class="evb-date" aria-hidden="true"><b>${ev.d.getDate()}</b><span>${MONS[ev.d.getMonth()]}</span><small>${DOW[ev.d.getDay()]}</small></div>
    <div class="evb-body">
      <div class="evb-tags"><span class="chip accent">${ev.cat}</span>${ev.joint?`<span class="chip joint">совместно · ${esc(ev.joint)}</span>`:""}${dd<=3?`<span class="chip warn">${relDays(dd)}</span>`:""}</div>
      <h3>${esc(ev.t)}</h3>
      <p class="evb-meta">${fmtDate(ev.d)}, ${DOWF[ev.d.getDay()]} · ${ev.s}–${ev.e}<br>${esc(ev.place)} · ${esc(ev.org)}</p>
      ${hero?`<p class="evb-desc">${esc(ev.desc)}</p>`:""}
      <div class="evb-act"><button class="btn sm ${go?"":"ghost"}" data-action="evgo" data-id="${ev.id}" aria-pressed="${go}">${go?ic("check","i s")+"Иду":"Пойду"}</button>
        <button class="btn sm ghost" data-action="evmore" data-id="${ev.id}">Подробнее</button><span class="evb-n">${n} ${plural(n,"идёт","идут","идут")}</span></div>
    </div></article>`;
}
function vEvents(){
  const f = S.evFilter, list = EVENTS.filter(ev => f==="all" || (f==="joint" ? ev.joint : f==="mine" ? evGoing(ev) : ev.cat===f));
  const mine = EVENTS.filter(evGoing).length;
  return `<div class="evb-filter" role="group" aria-label="Фильтр мероприятий">${EV_CATS.map(([k,n])=>`<button data-action="evf" data-k="${k}" aria-pressed="${f===k}">${n}${k==="mine"&&mine?` <span class="ms-badge">${mine}</span>`:""}</button>`).join("")}</div>
    <div class="evb-grid">${list.map((ev,i)=>evCard(ev, i===0 && f==="all")).join("") || `<div class="empty">${f==="mine"?"Вы пока никуда не записались.":"В этой категории пока ничего нет."}</div>`}</div>`;
}
function evToggle(id){
  const ev = EVENTS.find(x=>x.id===id);
  if(evGoing(ev)){ window.lkMy.del("ev-"+id); toast("Убрано из расписания"); }
  else { window.lkMy.add(evKey(ev.d), {id:"ev-"+id, s:toMin(ev.s), e:toMin(ev.e), t:ev.t, ty:"Мероприятие", room:ev.place, who:ev.org}); toast("Добавлено в расписание: " + fmtDate(ev.d)); }
}
function evMore(id){
  const ev = EVENTS.find(x=>x.id===id), go = evGoing(ev);
  openSheet(ev.t, `<p style="margin:0 0 14px">${esc(ev.desc)}</p>
    <dl class="kv"><dt>Когда</dt><dd>${fmtDate(ev.d)}, ${DOWF[ev.d.getDay()]}, ${ev.s}–${ev.e}</dd><dt>Где</dt><dd>${esc(ev.place)}</dd><dt>Организатор</dt><dd>${esc(ev.org)}</dd>
      ${ev.joint?`<dt>Совместно с</dt><dd>${esc(ev.joint)}</dd>`:""}<dt>Участники</dt><dd>${ev.base+(go?1:0)}</dd></dl>
    <button class="btn block" data-action="evgo" data-id="${ev.id}" data-sheet="1" style="margin-top:18px">${go?"Не пойду":"Пойду — добавить в расписание"}</button>`);
}

function infoRow([label, val, secret], key){
  const open = !secret || S.shown[key];
  const shownVal = open ? esc(val) : "•".repeat(Math.min(10, val.length));
  return `<div class="pf-row"><dt>${label}</dt><dd><span class="pf-v ${open?"":"masked"}">${shownVal}</span>${secret ? `<span class="pf-tools">
      ${open && /Пароль|Логин|почта/.test(label) ? `<button class="iconbtn sm" data-action="pfcopy" data-k="${key}" aria-label="Скопировать: ${label}">${ic("copy","i s")}</button>` : ""}
      <button class="iconbtn sm" data-action="pfeye" data-k="${key}" aria-pressed="${open}" aria-label="${open?"Скрыть":"Показать"}: ${label}">${ic(open?"eyeoff":"eye","i s")}</button></span>` : ""}</dd></div>`;
}
function vProfile(){
  if(S.view==="requests") return vRequests();
  const cnt = k => S.reqs.filter(r=>r.step<3 && kindOf(r)===k).length;
  const docBtn = (k, t, sub) => { const n = k==="all" ? S.reqs.filter(r=>r.step<3).length : cnt(k);
    return `<button class="pf-doc" data-action="docs" ${k==="all"?"":`data-k="${k}"`}>${ic(k==="app"?"requests":k==="all"?"grades":"doc","i")}<span class="grow"><b>${t}</b><small>${sub}</small></span>${n?`<span class="chip mark">${n}</span>`:""}${ic("arrow","i s")}</button>`; };
  return `<div class="view">
    ${pageH("Профиль")}
    <div class="pf-top">
      <section class="idcard" aria-label="Студенческий билет">
        <div class="who"><span class="ph">${STUDENT.initials}</span><div style="min-width:0"><span class="eyebrow" style="color:inherit;opacity:.7">Студенческий билет № ${STUDENT.id}</span><h2>${STUDENT.fio}</h2></div></div>
        <div class="grid"><div><small>Институт</small>ИИТ</div><div><small>Группа</small>${STUDENT.group}</div><div><small>Курс</small>${STUDENT.course}</div><div><small>Действует до</small>31.08.2027</div></div>
        <button class="btn" data-action="card" style="background:var(--mark);color:var(--mark-ink)">${ic("card","i s")}Показать QR для входа</button>
      </section>
      <div class="pf-docs">
        ${docBtn("cert", "Справки", "Заказать, скачать готовые")}
        ${docBtn("app", "Заявления", "Подать и отследить")}
        ${docBtn("all", "Документы", "Мои заявки и архив")}
      </div>
    </div>
    <section class="card pf-info" aria-label="Данные студента">
      <div class="seg pf-tabs" role="tablist" aria-label="Окна профиля">${PROFILE_INFO.map((p,i)=>`<button role="tab" data-action="pftab" data-i="${i}" aria-pressed="${S.infoTab===i}" aria-selected="${S.infoTab===i}">${p.t}</button>`).join("")}</div>
      <div class="pf-track" id="pfTrack">${PROFILE_INFO.map(p=>`<div class="pf-pane" role="tabpanel" aria-label="${p.t}"><h2>${p.t==="Основное"?"Основная информация":p.t==="Личное"?"Персональная информация":"Контакты"}</h2>
        <dl class="pf-list">${p.rows.map((r,j)=>infoRow(r, p.id+j)).join("")}</dl></div>`).join("")}</div>
      <p class="muted small" style="margin-top:12px">Нашли ошибку в данных? <button class="link" data-go="inbox" data-tab="chat">Напишите методисту</button></p>
    </section>
  </div>`;
}

const tg = (id, on, label, sub, act="pref") => `<div class="row"><span class="grow"><b style="font-weight:500">${label}</b>${sub?`<br><span class="muted small">${sub}</span>`:""}</span><label class="toggle"><input type="checkbox" id="${id}" data-action="${act}" data-k="${id}" ${on?"checked":""} aria-label="${label}"><span></span></label></div>`;
const SVG = p => `<svg viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
const THEMES = [["light","Светлая",'<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>'],
  ["auto","Авто",""], ["dark","Тёмная",'<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>']];
const CLOCKS = [["classic","Классика",'<div class="pv">09:41</div>'], ["thin","Тонкие",'<div class="pv thin">09:41</div>'], ["stack","Стопка",'<div class="pv stack">09<i>41</i></div>']];
/* выбор фона: готовые варианты и своё фото (файл не уходит с устройства) */
function bgPick(U){
  const ph = window.lkUI.photo(), cur = document.documentElement.dataset.bg;
  const tiles = window.lkUI.bgs.map(([v,n,t,ob,ow]) => {
    if(v==="photo") return ph
      ? `<button role="radio" data-action="bgpick" data-v="photo" aria-checked="${cur==="photo"}"><span class="sw photo" style="background-image:url(${ph.src})"></span>${n}</button>`
      : `<label class="bg-up" role="radio" aria-checked="false" tabindex="0"><input type="file" id="bgFile" accept="image/*" class="sr" aria-label="Загрузить своё фото для фона"><span class="sw add">${SVG('<path d="M12 5v14M5 12h14"/>')}</span>${n}</label>`;
    return `<button role="radio" data-action="bgpick" data-v="${v}" aria-checked="${cur===v}"><span class="sw" data-v="${v}" ${t?`style="--bgt:${t};--ob:${ob};--ow:${ow}"`:""}></span>${n}</button>`;
  }).join("");
  return `<div class="bg-pick" role="radiogroup" aria-label="Фон">${tiles}</div>
    ${ph?`<label class="link bg-change"><input type="file" id="bgFile" accept="image/*" class="sr" aria-label="Выбрать другое фото">Другое фото</label>`:""}`;
}
function vSettings(){
  const U = window.lkUI.get(), ti = THEMES.findIndex(t=>t[0]===U.theme);
  return `<div class="view">
    ${pageH("Настройки")}
    <div class="cols">
      <div class="stack">
        <section class="card"><div class="card-h"><h2>Безопасность</h2>${ic("shield","i s")}</div>
          <div class="list">
            ${tg("tfa", S.tfa, "Вход с кодом подтверждения", "Код из приложения при входе с нового устройства")}
            <div><div class="row" style="margin-bottom:8px"><b class="grow" style="font-weight:500">Где выполнен вход</b><span class="muted small">${S.devices.length}</span></div>
              <div style="display:grid;gap:8px">${S.devices.map(d=>`<div class="row small"><span class="grow">${esc(d.n)}<br><span class="muted">${d.cur?"это устройство":esc(d.w)}</span></span>${d.cur?'<span class="chip ok">Активно</span>':`<button class="btn sm ghost" data-action="kill" data-id="${d.id}">Завершить</button>`}</div>`).join("")}</div></div>
          </div>
        </section>
        <section class="card"><div class="card-h"><h2>Уведомления и приватность</h2></div>
          <div class="list">
            ${tg("sched", S.prefs.sched, "Изменения расписания", "Сразу, push")}
            ${tg("dead", S.prefs.dead, "Сроки и дедлайны", "За 5 дней и за день")}
            ${tg("news", S.prefs.news, "Новости вуза", "Раз в неделю, подборкой")}
            ${tg("phone", S.prefs.phone, "Показывать мой телефон группе", "Видят только одногруппники и куратор")}
          </div>
        </section>
      </div>
      <div class="stack set-look">
        <section class="card look" aria-label="Внешний вид"><div class="card-h"><h2>Внешний вид</h2></div>
          <div class="ap-row"><b>Тема</b>
            <div class="theme-sw" role="radiogroup" aria-label="Тема" style="--i:${ti}"><span class="knob"></span>
              ${THEMES.map(([v,n,p])=>`<button role="radio" data-action="theme" data-v="${v}" aria-checked="${U.theme===v}" aria-label="${n}" title="${n}">${p?SVG(p):"Авто"}</button>`).join("")}</div></div>
          <div class="ap-row"><b>Эффект Liquid Glass <small id="glassVal">${U.glass}%</small></b>
            <div class="glass-rng"><input type="range" id="glassRng" min="0" max="100" step="5" value="${U.glass}" style="--v:${U.glass}%" aria-label="Сила эффекта жидкого стекла">
              <div class="ends"><span>Матовое</span><span>Прозрачное</span></div></div></div>
          <div class="ap-row"><b>Стиль часов</b>
            <div class="clock-pick" role="radiogroup" aria-label="Стиль часов">${CLOCKS.map(([v,n,pv])=>`<button role="radio" data-action="clockst" data-v="${v}" aria-checked="${U.clock===v}">${pv}${n}</button>`).join("")}</div></div>
          <div class="ap-row"><b>Фон</b>${bgPick(U)}</div>
          <div class="ap-row ap-tint">${tg("tint", U.tint, "Оттенок стекла под фон", "Стекло, карточки и док подхватывают цвет фона", "uipref")}</div>
          <div class="ap-row"><button class="ap-link" data-action="access"><span class="grow">Универсальный доступ<small>Иконки и порядок дока, крупный текст, меньше движения</small></span><span class="go">${SVG('<path d="m6 7 5 5-5 5M13 7l5 5-5 5"/>')}</span></button></div>
        </section>
      </div>
    </div>
    <button class="btn ghost block" data-action="logout" style="margin-top:16px;max-width:420px">${ic("key","i s")}Выйти из кабинета</button>
  </div>`;
}

function vAccess(){
  const U = window.lkUI.get(), IC = window.lkUI.icons, L = Object.fromEntries(window.lkUI.dockAll.map(d=>[d.id,d.label])), cfg = U.dock;
  const up = SVG('<path d="m6 15 6-6 6 6"/>'), dn = SVG('<path d="m6 9 6 6 6-6"/>');
  return `<div class="view">
    ${pageH("Универсальный доступ")}
    <div class="cols">
      <section class="card"><div class="card-h"><h2>Док</h2><button class="link" data-action="dkreset">Как было</button></div>
        <div class="dk-preview glass" aria-label="Так выглядит док">${cfg.filter(c=>c.on).map(c=>`<span title="${L[c.id]}">${SVG(IC[c.id][c.ic])}</span>`).join("")}</div>
        <p class="muted small" style="margin:6px 0 4px">Стрелки меняют порядок, переключатель убирает пункт из дока, а иконку можно выбрать из трёх.</p>
        <div class="dk-list">${cfg.map((c,i)=>`<div class="dk-row ${c.on?"":"off"}" data-id="${c.id}">
          <span class="dk-move"><button data-action="dkmove" data-id="${c.id}" data-d="-1" ${i===0?"disabled":""} aria-label="${L[c.id]}: выше">${up}</button><button data-action="dkmove" data-id="${c.id}" data-d="1" ${i===cfg.length-1?"disabled":""} aria-label="${L[c.id]}: ниже">${dn}</button></span>
          <span class="dk-name">${L[c.id]}${c.id==="home"?"<small>всегда в доке</small>":""}</span>
          <span class="dk-icons" role="radiogroup" aria-label="Иконка: ${L[c.id]}">${IC[c.id].map((p,n)=>`<button role="radio" data-action="dkicon" data-id="${c.id}" data-n="${n}" aria-checked="${c.ic===n}" aria-label="Вариант ${n+1}">${SVG(p)}</button>`).join("")}</span>
          ${c.id==="home" ? `<span style="width:44px"></span>` : `<label class="toggle"><input type="checkbox" data-action="dkon" data-k="${c.id}" ${c.on?"checked":""} aria-label="Показывать «${L[c.id]}» в доке"><span></span></label>`}
        </div>`).join("")}</div>
      </section>
      <section class="card"><div class="card-h"><h2>Чтение и движение</h2></div>
        <div class="list">
          ${tg("big", U.big, "Крупный текст", "Разделы и карточки крупнее на 12 %", "uipref")}
          ${tg("calm", U.calm, "Меньше движения", "Без волны в доке, плавающих шаров и пружин", "uipref")}
        </div>
      </section>
    </div>
  </div>`;
}

/* ===== связка с app.js ===== */
const go = v => window.lkGo(v);
const VIEWS_ZK = { grades: vGrades, requests: vProfile, inbox: vInbox, profile: vProfile, settings: vSettings, access: vAccess };
function render(){
  const m = document.getElementById("zk-main");
  m.innerHTML = VIEWS_ZK[S.view]();
  pfMount();
  const chat = document.getElementById("chat"); if(chat) chat.scrollTop = chat.scrollHeight;
}
/* окна профиля листаются горизонтально (scroll-snap); переключатель и лента синхронны */
function pfMount(){
  const tr = document.getElementById("pfTrack"); if(!tr) return;
  tr.scrollLeft = S.infoTab * tr.clientWidth;
  let t; tr.addEventListener("scroll", () => { clearTimeout(t); t = setTimeout(() => {
    if(getComputedStyle(tr).overflowX === "visible") return;          // на широком экране окна стоят рядом
    const i = Math.round(tr.scrollLeft / tr.clientWidth); if(i === S.infoTab) return;
    S.infoTab = i; document.querySelectorAll(".pf-tabs button").forEach((b,k)=>{ b.setAttribute("aria-pressed", k===i); b.setAttribute("aria-selected", k===i); });
  }, 90); }, {passive:true});
}
/* ===== данные для поиска на главной: {g группа, t, s подпись, k ключевые слова, ic иконка, run} ===== */
function searchItems(){
  const out = [], CTRL = {lec:"лекция", prac:"практика", lab:"лабораторная", pe:"занятие"};
  CURRENT.forEach((c,i) => out.push({g:"Предметы", t:c.s, s:`${c.ctrl} · ${sumOf(c)} баллов`, k:"успеваемость оценки баллы", ic:"grades",
    run(){ S.gradeTab = "now"; S.openSubj[i] = true; go("grades"); }}));
  const who = {};
  Object.values(SCHEDULE).flat().forEach(l => { (who[l.who] = who[l.who] || new Set()).add(l.s);
    if(!CURRENT.some(c=>c.s===l.s)) out.push({g:"Предметы", t:l.s, s:`${TYPE[l.t][0]} · ${l.who}`, k:CTRL[l.t]+" расписание", ic:"schedule", run(){ go("schedule"); }}); });
  Object.entries(who).forEach(([n,set]) => out.push({g:"Преподаватели", t:n, s:[...set].join(", "), k:"преподаватель", ic:"user", run(){ go("schedule"); }}));
  CATALOG.forEach(c => out.push({g:"Справки и заявления", t:c.t, s:`${c.d} Срок: ${c.sla.toLowerCase()}.`, k:c.app?"заявление":"справка заказать", ic:"doc",
    run(){ showOrder(c.id); }}));
  S.reqs.forEach(r => out.push({g:"Мои заявки", t:r.t, s:`${r.id} · ${STEPS[r.step]}`, k:"заявка статус "+r.id, ic:"requests", run(){ go("requests"); }}));
  Object.entries(RECORD).forEach(([sem,list]) => list.forEach(([n,ctrl,g]) => out.push({g:"Оценки", t:n, s:`${sem} семестр · ${ctrl} · ${g} из 100, ${markOf(g,ctrl)[0]}`, k:"зачётка оценка",
    ic:"grades", run(){ S.gradeTab = "record"; S.sem = +sem; go("grades"); }})));
  DEADLINES.forEach(d => out.push({g:"Дедлайны", t:d.t, s:`${fmtDate(new Date(d.d))} · ${d.s}`, k:"дедлайн срок", ic:"clock", run(){ go("grades"); }}));
  DEFAULT_NOTES.forEach(n => out.push({g:"Уведомления", t:n.t, s:n.p, k:"уведомление", ic:NOTE_ICON[n.k],
    run(){ if(!S.read.includes(n.id)){ S.read.push(n.id); save(); } go(n.go || "inbox"); }}));
  PEOPLE.forEach(p => out.push({g: p.k==="teacher" ? "Преподаватели" : "Студенты", t:p.n, s:p.role + " · написать", k:"написать сообщение чат мессенджер " + p.info.map(r=>r[1]).join(" "), ic:"user",
    run(){ if(!CHATS.some(c=>c.id===p.id)){ CHATS.unshift(personChat(p)); S.people.push(p.id); } S.inboxTab = "chat"; S.chatId = p.id; S.chatOpen = true; save(); go("inbox"); }}));
  EVENTS.forEach(ev => out.push({g:"Мероприятия", t:ev.t, s:`${fmtDate(ev.d)}, ${ev.s} · ${ev.place}`, k:"мероприятие событие афиша " + ev.cat + " " + (ev.joint||""), ic:"news",
    run(){ S.inboxTab = "events"; go("inbox"); evMore(ev.id); }}));
  out.push({g:"Профиль", t:"Студенческий билет", s:`${STUDENT.group} · № ${STUDENT.id}`, k:"билет qr пропуск", ic:"card", run(){ go("profile"); showCard(); }},
    {g:"Профиль", t:"Чат с деканатом", s:"Ирина Волкова, методист", k:"методист деканат написать вопрос", ic:"chat", run(){ S.inboxTab = "chat"; S.chatId = "dean"; S.chatOpen = true; go("inbox"); }},
    {g:"Настройки", t:"Безопасность и устройства", s:"Сеансы, код подтверждения", k:"пароль устройства выход", ic:"shield", run(){ go("settings"); }});
  return out;
}
window.ZK = { show(v){ S.view = v; render(); }, picker: k => openPicker(k), order: showOrder, inbox(arg){ if(arg==="news"){ S.inboxTab = "notes"; } else if(arg==="events"){ S.inboxTab = "events"; } else if(CHATS.some(c=>c.id===arg)){ S.inboxTab = "chat"; S.chatId = arg; S.chatOpen = true; if(!S.chatRead.includes(arg)) S.chatRead.push(arg); } render(); }, unread, student: STUDENT, searchItems, icon: n => ic(n), sheet: openSheet, closeSheet: () => closeSheet(), toast };
/* ===== тост ===== */
let toastT;
function toast(t){
  const r = document.getElementById("toastRoot");
  r.innerHTML = `<div class="toast" role="status">${esc(t)}</div>`;
  clearTimeout(toastT); toastT = setTimeout(()=>{ r.innerHTML=""; }, 2600);
}

/* ===== листы ===== */
function openSheet(title, html, onMount){
  const root = document.getElementById("sheetRoot");
  root.innerHTML = `<div class="sheet-wrap" data-action="closesheet"><div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="grab"></div>
    <div class="sh"><h2>${esc(title)}</h2><button class="iconbtn" data-action="closesheet" aria-label="Закрыть">${ic("close","i s")}</button></div>${html}</div></div>`;
  const first = root.querySelector("input,select,textarea,button.btn");
  if(first) setTimeout(()=>first.focus({preventScroll:true}), 50);
  if(onMount) onMount(root);
}
function closeSheet(instant){
  const root = document.getElementById("sheetRoot"), gm = root.querySelector(".gm");
  if(!gm || instant || gm.dataset.closing){ root.innerHTML = ""; return; }
  gm.dataset.closing = 1;
  const from = document.querySelector(`[data-action="picker"][data-k="${gm.dataset.k}"]`);
  // запасной таймер: анимации стоят, пока вкладка не отрисовывается (фон, headless)
  const done = () => { if(root.contains(gm)) root.innerHTML = ""; if(from) from.style.visibility = ""; };
  morph(gm, from, true).then(done); setTimeout(done, 520);
}

/* псевдо-QR: узор для демонстрации, не настоящий код */
function drawQR(canvas, seed){
  const n = 25, px = canvas.width / n, ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0,0,canvas.width,canvas.height);
  let s = 0; for(const ch of seed) s = (s*31 + ch.charCodeAt(0)) >>> 0;
  const rnd = () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  ctx.fillStyle = "#111";
  const finder = (x,y) => { ctx.fillRect(x*px,y*px,7*px,7*px); ctx.fillStyle="#fff"; ctx.fillRect((x+1)*px,(y+1)*px,5*px,5*px); ctx.fillStyle="#111"; ctx.fillRect((x+2)*px,(y+2)*px,3*px,3*px); };
  for(let y=0;y<n;y++) for(let x=0;x<n;x++){
    const inF = (x<8&&y<8)||(x>n-9&&y<8)||(x<8&&y>n-9);
    if(!inF && rnd() > .52) ctx.fillRect(x*px,y*px,px,px);
  }
  finder(0,0); finder(n-7,0); finder(0,n-7);
}

function showCard(){
  openSheet("Студенческий билет", `<div style="display:grid;gap:16px;justify-items:center;text-align:center">
    <div class="idcard" style="width:100%;text-align:left"><div class="who"><span class="ph">${STUDENT.initials}</span><div><span class="eyebrow" style="color:inherit;opacity:.7">№ ${STUDENT.id} · до 31.08.2027</span><h2>${STUDENT.fio}</h2></div></div></div>
    <canvas class="qr" id="qr" width="225" height="225" style="width:200px;height:200px;border:10px solid #fff"></canvas>
    <p class="muted small">Поднесите к турникету или покажите охране. Код обновляется каждые 30 секунд — снимок экрана не подойдёт.</p>
    <span class="chip accent" id="qrTimer">${ic("clock","i s")}обновится через 30 с</span>
  </div>`, root => {
    const c = root.querySelector("#qr"); let k = 0, t = 30; drawQR(c, "card"+k);
    const iv = setInterval(()=>{ if(!document.body.contains(c)){ clearInterval(iv); return; } t--; if(t<=0){ t=30; k++; drawQR(c,"card"+k); } const el=root.querySelector("#qrTimer"); if(el) el.lastChild.textContent = `обновится через ${t} с`; }, 1000);
  });
}

function orderFields(c){
  const id = c.id;
  if(!c.app) return `<div class="field"><label for="f-to-${id}">Куда предоставить</label><select id="f-to-${id}" name="to">
        ${(id==="army"?["Военный комиссариат"]:["По месту требования","Социальный фонд России","Работа родителей","Налоговая (вычет за обучение)","Банк","Визовый центр"]).map(o=>`<option>${o}</option>`).join("")}</select></div>
      <div class="field"><span class="lbl">Формат</span><div class="radios">
        <label><input type="radio" name="fmt" value="e" ${c.e?"checked":"disabled"}>Электронная<small>${c.e?"с подписью вуза, сразу":"недоступна для этой справки"}</small></label>
        <label><input type="radio" name="fmt" value="p" ${c.e?"":"checked"}>Бумажная<small>забрать в каб. 214-Б</small></label></div></div>
      <div class="row" style="gap:12px;flex-wrap:wrap"><div class="field" style="flex:1;min-width:120px"><label for="f-n-${id}">Количество</label><select id="f-n-${id}">${[1,2,3,4,5].map(n=>`<option>${n}</option>`).join("")}</select></div>
        <div class="field" style="flex:1;min-width:120px"><label for="f-lang-${id}">Язык</label><select id="f-lang-${id}"><option>Русский</option>${c.en?"<option>Английский</option>":""}</select></div></div>`;
  return `<div class="field"><label for="f-why-${id}">Причина</label><textarea id="f-why-${id}" name="why" placeholder="Коротко опишите ситуацию"></textarea></div>
      <div class="field"><label for="f-file-${id}">Документы</label><input type="file" id="f-file-${id}" multiple style="padding:10px 14px;height:auto"><span class="muted small">PDF или фото, до 10 МБ каждый</span></div>`;
}
function submitOrder(f){
  const c = CATALOG.find(x=>x.id===f.dataset.id);
  if(c.app && !f.elements.why.value.trim()){ const er = f.querySelector(".err"); er.textContent = "Опишите причину — без неё методист не сможет рассмотреть заявление."; er.hidden = false; f.elements.why.focus(); return; }
  const fmt = f.querySelector('input[name="fmt"]:checked'), isE = !!fmt && fmt.value === "e", to = f.elements.to, d = now();
  const r = { id:`З-${String(d.getFullYear()).slice(2)}${String(d.getMonth()+1).padStart(2,"0")}-${String(Math.floor(600+Math.random()*399)).padStart(4,"0")}`,
    t:c.t, sub: c.app ? "Заявление · онлайн" : `${to?to.value:""} · ${isE?"электронная":"бумажная"}`,
    step:0, date:d.toISOString().slice(0,10), doc:isE, purpose: to?to.value:"", info: c.app ? "Передано методисту" : isE ? "Формируется и подписывается" : `Будет готова: ${c.sla.toLowerCase()}` };
  S.reqs.unshift(r); save(); closeSheet(true); go("requests");
  toast(c.app ? "Заявление подано" : "Справка заказана");
  if(isE){
    setTimeout(()=>{ r.step = 1; r.info = "Подписывается электронной подписью"; save(); if(S.view==="requests") render(); }, 1400);
    setTimeout(()=>{ r.step = 2; r.info = "Готова. Можно открыть и отправить"; save(); if(S.view==="requests") render(); toast("Справка готова"); }, 3400);
  }
}
// заказ конкретной справки (поиск на главной, ссылка #docs:order): окно выбора с раскрытой формой
function showOrder(id){
  const c = CATALOG.find(x=>x.id===id); if(!c) return;
  if(S.view!=="requests") go("requests");
  openPicker(c.app ? "app" : "cert", id);
}

function showDoc(id){
  const r = S.reqs.find(x=>x.id===id); if(!r) return;
  const code = id.replace(/\D/g,"").slice(-6).replace(/(\d{3})(\d{3})/,"$1-$2");
  openSheet("Справка об обучении", `<div class="doc">
      <div class="dh">Министерство науки и высшего образования<br>Университет · Институт информационных технологий</div>
      <h3>СПРАВКА</h3>
      <p>Выдана <b>${STUDENT.fio}</b> в том, что она действительно обучается на ${STUDENT.course} курсе по очной форме обучения за счёт бюджетных ассигнований по направлению подготовки ${STUDENT.program}.</p>
      <p>Срок окончания обучения: 31 августа 2028 г.<br>Справка выдана для предоставления: ${esc(r.purpose||"по месту требования")}.</p>
      <p style="font-size:12px;color:#666">№ ${r.id} от ${fmtDate(new Date(r.date))} ${new Date(r.date).getFullYear()} г.</p>
      <div class="sign"><canvas id="docqr" width="100" height="100" style="width:72px;height:72px"></canvas><div>ДОКУМЕНТ ПОДПИСАН<br>ЭЛЕКТРОННОЙ ПОДПИСЬЮ<br><span style="color:#333">Код проверки: <b class="mono">${code}</b></span></div></div>
    </div>
    <p class="muted small" style="margin-top:12px">Это демонстрация: QR-узор и подпись условные. В рабочей версии получатель сканирует QR и видит оригинал на сайте вуза.</p>
    <button class="btn block" style="margin-top:12px" data-action="copylink" data-id="${r.id}">Скопировать код проверки</button>`,
    root => drawQR(root.querySelector("#docqr"), r.id));
}

/* ===== события ===== */
document.addEventListener("click", e => {
  const g = e.target.closest("[data-go]");
  if(g){ if(g.dataset.tab) S.inboxTab = g.dataset.tab; if(g.dataset.tab==="chat"){ S.chatId = "dean"; S.chatOpen = true; } if(g.closest("#sheetRoot")) closeSheet(true); return; }
  const a = e.target.closest("[data-action]");
  if(!a) return;
  const act = a.dataset.action;
  if(act==="closesheet"){ if(e.target===a || a.tagName==="BUTTON") closeSheet(); return; }
  if(act==="pref") return;
  switch(act){
    case "day": S.day = +a.dataset.w; render(); break;
    case "guide": {
      e.preventDefault();
      const panel = document.getElementById(a.getAttribute("aria-controls"));
      panel.hidden = !panel.hidden;
      a.setAttribute("aria-expanded", String(!panel.hidden));
      break;
    }
    case "gtab": S.gradeTab = a.dataset.t; render(); break;
    case "sem": S.sem = +a.dataset.n; render(); break;
    case "subj": S.openSubj[a.dataset.i] = !S.openSubj[a.dataset.i]; render(); break;
    case "nf": S.noteFilter = a.dataset.k; render(); break;
    case "itab": S.inboxTab = a.dataset.t; render(); break;
    case "chat": S.chatId = a.dataset.id; S.chatOpen = true; if(!S.chatRead.includes(S.chatId)) S.chatRead.push(S.chatId); save(); render();
      if(innerWidth >= 760) document.getElementById("chatInput")?.focus({preventScroll:true}); break;
    case "chatback": S.chatOpen = false; render(); break;
    case "mskind": S.msKind = a.dataset.k; render(); if(matchMedia("(hover: hover)").matches) document.getElementById("msQ")?.focus({preventScroll:true}); break;   // на телефоне клавиатура сама не выезжает
    case "person": { const p = PEOPLE.find(x=>x.id===a.dataset.id);
      if(!CHATS.some(c=>c.id===p.id)){ CHATS.unshift(personChat(p)); S.people.push(p.id); }
      S.chatId = p.id; S.chatOpen = true; S.msQ = ""; S.msKind = "chats"; if(!S.chatRead.includes(p.id)) S.chatRead.push(p.id); save(); render();
      if(innerWidth >= 760) document.getElementById("chatInput")?.focus({preventScroll:true}); break; }
    case "evf": S.evFilter = a.dataset.k; render(); break;
    case "evgo": evToggle(a.dataset.id); if(a.dataset.sheet) closeSheet(true); if(S.view==="inbox") render(); break;
    case "evmore": evMore(a.dataset.id); break;
    case "bgpick": window.lkUI.set("bg", a.dataset.v); render(); break;
    case "chatinfo": { const c = CHATS.find(x=>x.id===S.chatId);
      openSheet(c.n, `<div class="row" style="margin-bottom:14px"><span class="avatar">${c.ini}</span><span class="grow muted small">${esc(c.role)}</span></div>
        <dl class="kv" style="margin:0">${c.info.map(([k,v])=>`<dt>${k}</dt><dd style="user-select:all;overflow-wrap:anywhere">${esc(v)}</dd>`).join("")}</dl>`); break; }
    case "docs": go("requests"); if(a.dataset.k) openPicker(a.dataset.k); break;
    case "pftab": { S.infoTab = +a.dataset.i; document.querySelectorAll(".pf-tabs button").forEach((b,k)=>{ b.setAttribute("aria-pressed", k===S.infoTab); b.setAttribute("aria-selected", k===S.infoTab); });
      const tr = document.getElementById("pfTrack"); tr.scrollTo({left: S.infoTab*tr.clientWidth, behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth"}); break; }
    case "pfeye": S.shown[a.dataset.k] = !S.shown[a.dataset.k]; render(); break;
    case "pfcopy": { const k = a.dataset.k, p = PROFILE_INFO.find(p=>k.startsWith(p.id)), row = p.rows[+k.slice(p.id.length)];
      const done = () => toast(`${row[0]}: скопировано`);
      try{ navigator.clipboard.writeText(row[1]).then(done, done); }catch(err){ done(); } break; }
    case "readall": S.read = DEFAULT_NOTES.map(n=>n.id); save(); render(); toast("Все уведомления прочитаны"); break;
    case "note": { const n = DEFAULT_NOTES.find(x=>x.id===a.dataset.id); if(!S.read.includes(n.id)) S.read.push(n.id); save(); if(n.go) go(n.go); else render(); break; }
    case "order": showOrder(a.dataset.id); break;
    case "picker": openPicker(a.dataset.k); break;
    case "gmopen": gmToggle(a.dataset.id); break;
    case "doc": showDoc(a.dataset.id); break;
    case "card": showCard(); break;
    case "copylink": { const code = a.dataset.id.replace(/\D/g,"").slice(-6).replace(/(\d{3})(\d{3})/,"$1-$2");
      const done = () => toast(`Код ${code} скопирован`);
      try{ navigator.clipboard.writeText(code).then(done, ()=>toast(`Код проверки: ${code}`)); }catch(err){ toast(`Код проверки: ${code}`); } break; }
    case "topic": { const inp = document.getElementById("chatInput"); inp.value = `${a.dataset.t}: `; inp.focus(); break; }
    case "kill": S.devices = S.devices.filter(d=>d.id!==a.dataset.id); save(); render(); toast("Сеанс завершён"); break;
    case "logout": window.lkLogout(); break;
    case "theme": { window.lkUI.set("theme", a.dataset.v); const sw = a.parentElement; sw.style.setProperty("--i", THEMES.findIndex(t=>t[0]===a.dataset.v));
      sw.querySelectorAll("button").forEach(b=>b.setAttribute("aria-checked", b===a)); break; }
    case "clockst": window.lkUI.set("clock", a.dataset.v); a.parentElement.querySelectorAll("button").forEach(b=>b.setAttribute("aria-checked", b===a)); toast("Стиль часов: " + a.textContent.trim()); break;
    case "access": go("access"); break;
    case "dkmove": { const cfg = window.lkUI.get().dock, i = cfg.findIndex(c=>c.id===a.dataset.id), j = i + +a.dataset.d;
      if(j<0 || j>=cfg.length) break; [cfg[i], cfg[j]] = [cfg[j], cfg[i]]; window.lkUI.set("dock", cfg); render();
      document.querySelector(`.dk-row[data-id="${a.dataset.id}"] [data-d="${a.dataset.d}"]:not(:disabled)`)?.focus(); break; }
    case "dkicon": { const cfg = window.lkUI.get().dock; cfg.find(c=>c.id===a.dataset.id).ic = +a.dataset.n; window.lkUI.set("dock", cfg); render(); break; }
    case "dkreset": window.lkUI.set("dock", null); render(); toast("Док вернулся к исходному виду"); break;
  }
}, true);
document.addEventListener("change", e => {
  const t = e.target;
  if(t.id === "bgFile" && t.files[0]){
    window.lkUI.setPhoto(t.files[0]).then(kept => { if(S.view==="settings") render(); toast(kept ? "Фон обновлён" : "Фото большое: фон сохранится только до перезагрузки"); }, () => toast("Не получилось открыть изображение"));
    return;
  }
  if(t.id === "chatFile" && t.files[0]){ const f = t.files[0]; sendChat({me:true, t:"", file:`${f.name} · ${Math.max(1, Math.round(f.size/1024))} КБ`, w:stamp()}); return; }
  if(t.dataset && t.dataset.action==="pref"){
    const k = t.dataset.k;
    if(k==="tfa"){ S.tfa = t.checked; toast(t.checked ? "Код подтверждения включён" : "Код подтверждения выключен"); }
    else { S.prefs[k] = t.checked; }
    save();
  }
  if(t.dataset && t.dataset.action==="uipref") window.lkUI.set(t.dataset.k, t.checked);
  if(t.dataset && t.dataset.action==="dkon"){ const cfg = window.lkUI.get().dock; cfg.find(c=>c.id===t.dataset.k).on = t.checked; window.lkUI.set("dock", cfg); render(); }
});
document.addEventListener("input", e => {
  if(e.target.id === "gmQ"){
    const q = e.target.value.trim().toLowerCase(), its = [...document.querySelectorAll("#gmList .gm-it")];
    let n = 0; its.forEach(it => { const hit = !q || q.split(/\s+/).every(w => it.dataset.k.includes(w)); it.hidden = !hit; if(hit) n++; });
    document.querySelector("#gmList .gm-empty").hidden = n > 0;
    if(n === 1 && q.length > 2) gmToggle(its.find(it=>!it.hidden).dataset.id, true);
    return;
  }
  if(e.target.id === "msQ"){ S.msQ = e.target.value; document.getElementById("msItems").innerHTML = msItems(); return; }
  if(e.target.id !== "glassRng") return;
  const v = +e.target.value; e.target.style.setProperty("--v", v + "%");
  document.getElementById("glassVal").textContent = v + "%";
  window.lkUI.set("glass", v);
});
document.addEventListener("submit", e => {
  if(e.target.classList.contains("gm-form")){ e.preventDefault(); submitOrder(e.target); return; }
  if(e.target.id !== "composer") return;
  e.preventDefault();
  const inp = document.getElementById("chatInput"), v = inp.value.trim();
  if(!v) return;
  sendChat({me:true, t:v, w:stamp()});
  document.getElementById("chatInput")?.focus({preventScroll:true});
});
document.addEventListener("keydown", e => {
  if(e.key==="Escape") closeSheet();
  if((e.key==="Enter" || e.key===" ") && e.target.classList?.contains("bg-up")){ e.preventDefault(); e.target.querySelector("input").click(); }
});
})();
