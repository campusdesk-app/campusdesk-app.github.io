'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const css = getComputedStyle(document.documentElement);
const tok = n => parseFloat(css.getPropertyValue(n));
const reduceMQ = matchMedia('(prefers-reduced-motion: reduce)');
const reduced = () => reduceMQ.matches || UI.calm;
let account = 'student';
const isStaff = () => account === 'staff';

/* ---------- Внешний вид: тема, сила стекла, часы, док, доступность. Хранится только в этом браузере ---------- */
const UI_DEF = { theme: 'light', glass: 70, clock: 'classic', big: false, calm: false, dock: null, bg: 'spheres', tint: true };
// Фоны: [id, название, оттенок фона, голубые шары, белые шары]. Оттенок же подмешивается в стекло, если включена подстройка
const BGS = [['spheres', 'Сферы', '159,192,227', '110,158,204', '159,192,227'], ['dawn', 'Рассвет', '238,176,168', '236,150,140', '232,186,214'],
  ['mint', 'Мята', '134,200,178', '104,184,160', '168,214,204'], ['lilac', 'Сирень', '172,156,226', '146,128,214', '196,182,236'],
  ['sand', 'Песок', '222,190,140', '212,170,110', '232,206,162'], ['plain', 'Однотонный', null], ['photo', 'Своё фото', null]];
// своё фото хранится отдельно от настроек: {src: dataURL, rgb: средний цвет, l: яркость 0–1}
let BGIMG = (() => { try { return JSON.parse(localStorage.getItem('lk:bgimg')); } catch { return null; } })();
const UI = Object.assign({}, UI_DEF, (() => { try { return JSON.parse(localStorage.getItem('lk:ui')) || {}; } catch { return {}; } })());
const darkMQ = matchMedia('(prefers-color-scheme: dark)');
function applyUI() {
  const r = document.documentElement;
  r.dataset.theme = UI.theme;
  r.dataset.scheme = UI.theme === 'auto' ? (darkMQ.matches ? 'dark' : 'light') : UI.theme;
  r.dataset.clock = UI.clock;
  r.style.setProperty('--g', (UI.glass / 100).toFixed(2));
  r.classList.toggle('big-text', !!UI.big);
  r.classList.toggle('calm', !!UI.calm);
  $('#refract feDisplacementMap')?.setAttribute('scale', (UI.glass * .32).toFixed(1));   // 70 → 22, как было
  const photo = UI.bg === 'photo' && BGIMG, bg = BGS.find(b => b[0] === UI.bg && (b[0] !== 'photo' || photo)) || BGS[0];
  r.dataset.bg = bg[0];
  if (bg[2]) { r.style.setProperty('--bgt', bg[2]); r.style.setProperty('--ob', bg[3]); r.style.setProperty('--ow', bg[4]); }
  const bgNode = document.getElementById('bg');
  if (bgNode) bgNode.style.backgroundImage = photo ? `url(${BGIMG.src})` : '';
  r.style.setProperty('--veil', photo && BGIMG.l < .5 ? '.42' : '.18');   // тёмное фото в светлой теме приглушаем сильнее
  // подстройка оттенка стекла: к заливке стекла (--wf) подмешивается цвет фона, 14 % в светлой теме и 20 % в тёмной
  const tint = UI.tint && (photo ? BGIMG.rgb.join(',') : bg[2]);
  if (tint) {
    const dark = r.dataset.scheme === 'dark', base = dark ? [30, 47, 74] : [255, 255, 255], p = dark ? .2 : .14, t = tint.split(',').map(Number);
    r.style.setProperty('--wf', base.map((b, i) => Math.round(b + (t[i] - b) * p)).join(','));
  } else r.style.removeProperty('--wf');
  $('meta[name="theme-color"]')?.setAttribute('content', r.dataset.scheme === 'dark' ? '#0B1626' : '#F3F8FD');   // строка состояния на телефоне
}
darkMQ.addEventListener('change', () => { if (UI.theme === 'auto') applyUI(); });
applyUI();
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const pad = n => String(n).padStart(2, '0');
const cap = s => s[0].toUpperCase() + s.slice(1);
const fm = m => `${pad(m / 60 | 0)}:${pad(m % 60)}`;
const plural = (n, a, b, c) => { const m = Math.abs(n) % 100, k = m % 10; return m > 10 && m < 20 ? c : k > 1 && k < 5 ? b : k === 1 ? a : c; };
const durH = m => m >= 60 ? `${m / 60 | 0} ч${m % 60 ? ' ' + m % 60 + ' мин' : ''}` : `${m} мин`;

if (navigator.userAgentData?.brands?.some(b => /Chromium/.test(b.brand))) document.documentElement.classList.add('chromium');

/* ---------- Пружина (без фиксированных длительностей) ---------- */
const spring = (x, eps = .001) => ({ x, t: x, v: 0, eps });
function stepSpring(s, k, c, m, dt) {
  s.v += ((-k * (s.x - s.t) - c * s.v) / m) * dt;
  s.x += s.v * dt;
  const done = Math.abs(s.v) < s.eps * 20 && Math.abs(s.x - s.t) < s.eps;
  if (done) { s.x = s.t; s.v = 0; }
  return !done;
}

/* ---------- Даты и демо-расписание ---------- */
const MON = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'];
const MON_G = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const WD = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const WD_FULL = ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье'];
const dkey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const wdi = d => (d.getDay() + 6) % 7;
const startOfWeek = d => addDays(d, -wdi(d));
const today0 = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };
const sameDay = (a, b) => dkey(a) === dkey(b);
const nowMin = () => { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); };
const dayLabel = d => `${cap(WD_FULL[wdi(d)])}, ${d.getDate()} ${MON_G[d.getMonth()]}`;

const SUBJ = [
  ['Математический анализ', 'Петров А. В.', 0, 'Матан'], ['Программирование', 'Смирнова Е. И.', 1, 'Прогр.'], ['История России', 'Козлов Д. С.', 2, 'Ист.'],
  ['Английский язык', 'Морозова О. Н.', 3, 'Англ.'], ['Физика', 'Волков И. П.', 4, 'Физика'], ['Базы данных', 'Смирнова Е. И.', 1, 'БД'],
  ['Философия', 'Лебедева Т. А.', 2, 'Филос.'], ['Дискретная математика', 'Петров А. В.', 0, 'Дискр.']];
const SECOND_SUBJ = [
  ['Прикладная статистика', 'Иванова К. Н.', 0, 'Стат.'], ['Интерфейсы', 'Быков А. О.', 1, 'UX'],
  ['Управление проектами', 'Мельникова Е. С.', 2, 'Проект'], ['Английский язык', 'Киреева Л. В.', 3, 'Англ.']];
const STAFF_EVENTS = [
  ['Приём студентов', 'Учебный офис', 1, 'Приём'], ['Проверка заявок', 'Учебный офис', 2, 'Заявки'],
  ['Совещание учебного офиса', 'Учебный офис', 3, 'Совещ.']];
const subjectsForAccount = () => isStaff() ? STAFF_EVENTS : account === 'student2' ? SECOND_SUBJ : SUBJ;
const SLOTS = [[9, 0], [10, 45], [12, 40], [14, 20], [16, 0], [17, 40]];
const H0 = 8, H1 = 20; // видимые часы в «Дне»
const evCache = new Map();
function hash(s) { let h = 2166136261; for (const ch of s) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
// shortcut: расписание генерируется из даты, заменить на данные из БД на этапе 3 плана
function eventsFor(d) {
  const k = dkey(d);
  if (evCache.has(k)) return evCache.get(k);
  const subjects = subjectsForAccount();
  const h = hash(account === 'student' ? k : account + k), wd = wdi(d), busy = !isStaff() && k === dkey(addDays(today0(), 2)), list = [];
  if (wd < 6 || busy) {
    const n = busy ? 5 : wd === 5 ? 2 : 2 + h % 3, s0 = busy ? 0 : (h >>> 3) % 2;
    for (let i = 0; i < n; i++) {
      const [hh, mm] = SLOTS[s0 + i], sj = subjects[(h + i * 7 + (h >>> 9)) % subjects.length], s = hh * 60 + mm;
      list.push({ s, e: s + 90, t: sj[0], sh: sj[3], who: sj[1], c: sj[2], room: isStaff() ? 'каб. 214' : 'ауд. ' + (101 + (h >>> (i + 2)) % 320), ty: isStaff() ? 'Рабочий график' : ['Лекция', 'Практика', 'Лабораторная'][(h >>> (i + 5)) % 3] });
    }
    if (!isStaff() && (busy || h % 4 === 0)) list.push({ s: 660, e: 720, t: 'Консультация по курсовой', sh: 'Конс.', who: account === 'student2' ? 'Мельникова Е. С.' : 'Петров А. В.', c: 4, room: 'ауд. 214', ty: 'Консультация' });
  }
  for (const o of MY[k] || []) list.push({ ...o, sh: o.t.slice(0, 6), c: 5, own: true });
  list.sort((a, b) => a.s - b.s);
  evCache.set(k, list);
  return list;
}
// Свои занятия (долгое нажатие в календаре, «Пойду» на доске мероприятий): {дата: [{id, s, e, t, ty, room, who}]}, только в этом браузере
const myKey = () => account === 'student' ? 'lk:my' : 'lk:' + account + ':my';
function loadMy() { try { return JSON.parse(localStorage.getItem(myKey())) || {}; } catch { return {}; } }
let MY = loadMy();
function saveMy(k) { if (!MY[k]?.length) delete MY[k]; try { localStorage.setItem(myKey(), JSON.stringify(MY)); } catch { } evCache.delete(k); cal.built = []; if (curView === 'schedule') paint(); }
function addMy(k, ev) { (MY[k] = MY[k] || []).push(ev); saveMy(k); }
function delMy(id) { for (const k in MY) if (MY[k].some(o => o.id === id)) { MY[k] = MY[k].filter(o => o.id !== id); saveMy(k); } }
// первое свободное время в дне на dur минут, с 9:00 шагом 15 минут
function freeAt(d, dur = 90, from = 540) {
  const l = eventsFor(d);
  for (let s = from; s + dur <= H1 * 60; s += 15) if (!l.some(e => e.s < s + dur && s < e.e)) return s;
  return 18 * 60;
}
// Раскладка пересекающихся занятий по дорожкам
function lanes(list) {
  const out = list.map(ev => ({ ev, lane: 0, n: 1 })), ends = [];
  for (const o of out) {
    let l = ends.findIndex(e => e <= o.ev.s);
    if (l < 0) { l = ends.length; ends.push(0); }
    ends[l] = o.ev.e; o.lane = l;
  }
  for (const o of out) o.n = 1 + Math.max(...out.filter(p => p.ev.s < o.ev.e && o.ev.s < p.ev.e).map(p => p.lane));
  return out;
}

/* ---------- Вход ---------- */
const DEMO_ACCOUNTS = { student: 'lk-demo-2026', student2: 'lk-demo-02', staff: 'staff-demo-2026' };
function openApp() {
  $('#login').hidden = true;
  const app = $('#app');
  app.hidden = false;
  buildDock();
  measure();
  go('home');
  openDeepLink();
}
$('#loginForm').addEventListener('submit', e => {
  e.preventDefault();
  const form = e.target, login = form.elements.login.value.trim(), password = form.elements.password.value;
  const error = $('#loginError');
  if (!Object.hasOwn(DEMO_ACCOUNTS, login) || DEMO_ACCOUNTS[login] !== password) {
    error.textContent = 'Неверный логин или пароль';
    error.hidden = false;
    form.elements.password.value = '';
    return;
  }
  error.hidden = true;
  form.reset();
  account = login;
  MY = loadMy();
  evCache.clear();
  cal.built = [];
  window.ZK.signIn();
  openApp();
});

/* ---------- Главная: крупные часы ---------- */
const TITLES = { home: 'Главная', schedule: 'Расписание', study: 'Учёба', docs: 'Документы', inbox: 'Уведомления', profile: 'Профиль', settings: 'Настройки', access: 'Универсальный доступ' };
const MON_S = ['янв.', 'фев.', 'мар.', 'апр.', 'мая', 'июн.', 'июл.', 'авг.', 'сен.', 'окт.', 'ноя.', 'дек.'];
let lastMin = -1;
function tickHome(force) {
  const t = new Date(), min = t.getHours() * 60 + t.getMinutes();
  if (min === lastMin && !force) return;
  lastMin = min;
  $('#c-hh').textContent = pad(t.getHours());
  $('#c-mm').textContent = pad(t.getMinutes());
  $('#c-dow').textContent = WD[wdi(t)] + ',';
  $('#c-date').textContent = `${t.getDate()} ${MON_S[t.getMonth()]}`;
  $('#clock-big').setAttribute('aria-label', `${pad(t.getHours())}:${pad(t.getMinutes())}, ${dayLabel(t)}`);
  const n = nextLesson();
  $('#n-label').textContent = isStaff() ? 'Рабочий график · учебный офис' : n ? n.label : 'Занятий на неделе нет';
  $('#n-title').textContent = n ? n.e.t : '';
  $('#n-meta').textContent = n ? `${fm(n.e.s)}–${fm(n.e.e)} · ${n.e.room} · ${n.e.who}` : '';
}

/* ---------- Док ---------- */
// у каждого пункта три варианта иконки на выбор (Настройки → Универсальный доступ)
const ICONS = {
  home: ['<path d="M4 10.5 12 4l8 6.5V19a1 1 0 0 1-1 1h-4.5v-5.5h-5V20H5a1 1 0 0 1-1-1z"/>',
    '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v4.5l3 2"/>',
    '<rect x="4" y="4" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="2"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="2"/>'],
  schedule: ['<rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    '<rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M8 3v4M16 3v4M8 12h2M14 12h2M8 16h2M14 16h2"/>',
    '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1.2"/><circle cx="4.5" cy="12" r="1.2"/><circle cx="4.5" cy="18" r="1.2"/>'],
  study: ['<path d="M2.5 9 12 4.5 21.5 9 12 13.5z"/><path d="M6.5 11v4.5c0 1.5 2.5 3 5.5 3s5.5-1.5 5.5-3V11M21.5 9v5"/>',
    '<path d="M12 6.5C10 5 7 4.5 3.5 5v13c3.5-.5 6.5 0 8.5 1.5 2-1.5 5-2 8.5-1.5V5C17 4.5 14 5 12 6.5zM12 6.5v13"/>',
    '<path d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/>'],
  profile: ['<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
    '<rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16a3.4 3.4 0 0 1 6.4 0M14.5 10h3M14.5 13.5h2.5"/>',
    '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="10" r="2.8"/><path d="M6.6 18.2a6 6 0 0 1 10.8 0"/>'],
  inbox: ['<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    '<rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="m4 7 8 6 8-6"/>',
    '<path d="M4.5 5.5h15v10h-9l-4.5 3.5v-3.5H4.5z"/><path d="M8.5 9.5h7M8.5 12.5h4"/>'],
};
const DOCK_ALL = [
  { id: 'schedule', label: 'Расписание' }, { id: 'study', label: 'Учёба' }, { id: 'home', label: 'Главная' },
  { id: 'profile', label: 'Профиль' }, { id: 'inbox', label: 'Уведомления' }];
const DOCK = [];   // видимые пункты в порядке пользователя; заполняет buildDock()
// настройка дока: [{id, on, ic}] в нужном порядке; Главную скрыть нельзя
function dockCfg() {
  const def = DOCK_ALL.map(d => ({ id: d.id, on: true, ic: 0 }));
  if (!Array.isArray(UI.dock)) return def;
  const got = UI.dock.filter(c => ICONS[c.id]).map(c => ({ id: c.id, on: c.id === 'home' || c.on !== false, ic: clamp(c.ic | 0, 0, 2) }));
  def.forEach(d => { if (!got.some(c => c.id === d.id)) got.push(d); });
  return got;
}
const dock = $('#dock'), items = $('.dock-items', dock), dockBg = $('.dock-bg', dock), lens = $('.dock-lens', dock), tip = $('.dock-tip', dock);
let btns = [];
const DK = tok('--spring-k'), DC = tok('--spring-c'), DM = tok('--spring-m');
const SIG = tok('--wave-sigma'), AMP = tok('--wave-amp'), LIFT = tok('--wave-lift');
let S = [];
const lensX = spring(0, .05);
let rest = [], widths = [], W = 1, px = null, pressed = -1, active = 0, hoverI = -1, scrubbing = false, tipI = -1, tipTimer, dockRAF = 0, dockLast = 0, lensReady = false;
function buildDock() {
  DOCK.length = 0;
  dockCfg().filter(c => c.on).forEach(c => {
    const item = DOCK_ALL.find(d => d.id === c.id);
    DOCK.push({ ...item, label: isStaff() && item.id === 'study' ? 'Заявки' : item.label, ic: c.ic });
  });
  items.innerHTML = DOCK.map((d, i) => `<button class="dock-item" data-i="${i}" aria-label="${d.label}" tabindex="${d.id === 'home' ? 0 : -1}"><svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[d.id][d.ic]}</svg></button>`).join('');
  btns = $$('.dock-item', items);
  S = btns.map(() => ({ s: spring(1), y: spring(0, .05) }));
  active = Math.min(active, btns.length - 1); lensReady = false; tipI = -1; hideTip();
}
buildDock();

function measure() {
  rest = btns.map(b => b.offsetLeft + b.offsetWidth / 2);
  widths = btns.map(b => b.offsetWidth);
  W = dock.offsetWidth || 1;
  kick();
}
function kick() { if (!dockRAF) { dockLast = performance.now(); dockRAF = requestAnimationFrame(dockTick); } }
function dockTick(now) {
  const dt = Math.min(.032, (now - dockLast) / 1000); dockLast = now;
  let moving = false;
  btns.forEach((b, i) => {
    let g = 0;
    if (px !== null && !reduced()) { const d = px - rest[i]; g = Math.exp(-(d * d) / (2 * SIG * SIG)); }
    S[i].s.t = (1 + AMP * g) * (i === pressed ? .92 : 1);
    S[i].y.t = -LIFT * g;
    if (stepSpring(S[i].s, DK, DC, DM, dt)) moving = true;
    if (stepSpring(S[i].y, DK, DC, DM, dt)) moving = true;
  });
  // Увеличенные иконки раздвигают соседей, а сама плашка растягивается на их прирост
  let ext = S.map((o, i) => (o.s.x - 1) * widths[i]), E = ext.reduce((a, b) => a + b, 0);
  const room = innerWidth - 24 - W;
  if (E > room) { const k = Math.max(0, room) / E; ext = ext.map(e => e * k); E *= k; }
  let acc = 0;
  const shift = ext.map(e => { const x = acc + e / 2 - E / 2; acc += e; return x; });
  btns.forEach((b, i) => { b.style.transform = `translate(${shift[i].toFixed(2)}px,${S[i].y.x.toFixed(2)}px) scale(${S[i].s.x.toFixed(4)})`; });
  dockBg.style.transform = `scaleX(${((W + Math.max(0, E)) / W).toFixed(4)})`;

  const lx = 8 + rest[active] + shift[active] - widths[active] / 2;
  if (!lensReady || reduced()) { lensX.x = lensX.t = lx; lensX.v = 0; lensReady = true; }
  lensX.t = lx;
  if (stepSpring(lensX, DK, DC, DM, dt)) moving = true;
  const st = 1 + Math.min(.5, Math.abs(lensX.v) / 1600); // капля вытягивается по ходу движения
  lens.style.transform = `translate(${lensX.x.toFixed(2)}px,${S[active].y.x.toFixed(2)}px) scale(${(st * S[active].s.x).toFixed(4)},${(S[active].s.x / Math.sqrt(st)).toFixed(4)})`;
  if (tipI >= 0) tip.style.transform = `translate(${(8 + rest[tipI] + shift[tipI] - tip.offsetWidth / 2).toFixed(1)}px,${S[tipI].y.x.toFixed(1)}px)`;
  dockRAF = moving || px !== null ? requestAnimationFrame(dockTick) : 0;
}
function showTip(i, ms) {
  clearTimeout(tipTimer);
  tipI = i; tip.textContent = DOCK[i].label; tip.classList.add('on'); kick();
  if (ms) tipTimer = setTimeout(hideTip, ms);
}
function hideTip() { tip.classList.remove('on'); }
const idxAt = x => rest.reduce((best, r, i) => Math.abs(x - r) < Math.abs(x - rest[best]) ? i : best, 0);
function setPx(e) {
  px = e.clientX - items.getBoundingClientRect().left;
  const i = idxAt(px);
  if (i !== hoverI) {
    if (scrubbing && e.pointerType === 'touch' && hoverI >= 0) navigator.vibrate?.(8);
    hoverI = i; showTip(i);
  }
  kick();
}
function dockReset() { px = null; hoverI = -1; pressed = -1; scrubbing = false; hideTip(); kick(); }
dock.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') setPx(e); });
dock.addEventListener('pointermove', e => { if (e.pointerType === 'mouse' || scrubbing) setPx(e); });
dock.addEventListener('pointerleave', () => { if (!scrubbing) dockReset(); });
dock.addEventListener('pointerdown', e => {
  if (e.button) return;
  e.preventDefault();
  try { dock.setPointerCapture(e.pointerId); } catch { }
  scrubbing = true; setPx(e); pressed = hoverI; kick();
});
dock.addEventListener('pointerup', e => {
  if (!scrubbing) return;
  const r = dock.getBoundingClientRect(), i = idxAt(px);
  const inside = e.clientY > r.top - 40 && e.clientY < r.bottom + 30 && e.clientX > r.left - 10 && e.clientX < r.right + 10;
  scrubbing = false; pressed = -1;
  if (inside) { ripple(e.clientX - r.left, e.clientY - r.top); activate(i); }
  if (e.pointerType !== 'mouse') { px = null; hoverI = -1; showTip(i, 900); }
  kick();
});
dock.addEventListener('pointercancel', dockReset);
items.addEventListener('click', e => { // клавиатура (Enter/Space); касания и мышь обрабатываются в pointerup
  const b = e.target.closest('.dock-item');
  if (b && e.detail === 0) activate(+b.dataset.i);
});
items.addEventListener('keydown', e => {
  const i = btns.indexOf(document.activeElement);
  if (i < 0) return;
  let n = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: btns.length - 1 }[e.key];
  if (n === undefined) return;
  e.preventDefault();
  n = (n + btns.length) % btns.length;
  btns.forEach((b, j) => { b.tabIndex = j === n ? 0 : -1; });
  btns[n].focus();
  px = rest[n]; hoverI = n; showTip(n); kick();
});
dock.addEventListener('focusout', e => { if (!dock.contains(e.relatedTarget) && !scrubbing) dockReset(); });
function ripple(x, y) {
  const r = document.createElement('span');
  r.className = 'ripple'; r.style.left = x + 'px'; r.style.top = y + 'px';
  dock.append(r); setTimeout(() => r.remove(), 700);
}
function activate(i) { go(DOCK[i].id); }

// док при прокрутке не меняется: сжатие на каждое движение пальца давало мигание
addEventListener('resize', () => { measure(); if (!$('#v-schedule').hidden) { cal.origin = null; paint(); } });

/* ---------- Ближайшая пара ---------- */
function nextLesson() {
  const t = today0(), m = nowMin();
  const cur = eventsFor(t).find(e => e.e > m);
  if (cur) return { e: cur, label: cur.s <= m ? 'Сейчас идёт' : 'Следующая пара', day: 'сегодня' };
  for (let i = 1; i < 8; i++) {
    const d = addDays(t, i), e = eventsFor(d)[0];
    if (e) return { e, label: i === 1 ? 'Завтра' : dayLabel(d), day: '' };
  }
  return null;
}
/* ---------- Навигация ---------- */
const ALIAS = { grades: 'study', requests: 'docs', today: 'home' };       // id разделов шаблона → наши
const ZK_VIEW = { study: 'grades', docs: 'requests', inbox: 'inbox', profile: 'profile', settings: 'settings', access: 'access' };
const DOCK_OF = { docs: 'profile' };                                    // Документы живут внутри Профиля
let curView = 'home', navStack = [];
// «Назад» возвращает на предыдущий экран; если истории нет — на главную
function back() { go(navStack.pop() || 'home', true); }
function go(id, noPush) {
  id = ALIAS[id] || id;
  if (!TITLES[id]) id = 'home';
  if (isStaff() && id === 'docs') id = 'study';
  if (!noPush && id !== curView) { navStack.push(curView); if (navStack.length > 30) navStack.shift(); }
  if (id === 'home') navStack = [];
  curView = id;
  $('#v-home').hidden = id !== 'home';
  $('#v-schedule').hidden = id !== 'schedule';
  $('#v-zk').hidden = !ZK_VIEW[id];
  if (ZK_VIEW[id]) window.ZK.show(ZK_VIEW[id]);
  if (id === 'home') tickHome(true);
  markDock(true);
  scrollTo(0, 0);
  if (id === 'schedule') {
    if (!cal.opened) { cal.opened = true; cal.Z.x = cal.Z.t = innerWidth < 760 ? 3 : 2; }
    cal.origin = null; header(); paint(); scrollToNow();
  }
  kick();
}
function markDock(tipToo) {
  const i = DOCK.findIndex(d => d.id === (DOCK_OF[curView] || curView));
  btns.forEach(b => b.removeAttribute('aria-current'));
  if (i >= 0) { btns[i].setAttribute('aria-current', 'page'); active = i; lens.style.opacity = 1; if (tipToo) showTip(i, 1100); }
  else lens.style.opacity = 0;
  kick();
}
window.lkGo = go;
window.lkUI = {
  get: () => ({ ...UI, dock: dockCfg() }),
  icons: ICONS, get dockAll(){ return isStaff() ? DOCK_ALL.map(d=>d.id==='study' ? {...d,label:'Заявки'} : d) : DOCK_ALL; }, bgs: BGS, photo: () => BGIMG,
  // фото уменьшается до 1920 px и сжимается в JPEG; средний цвет берётся с уменьшенной копии 32×32
  async setPhoto(file) {
    const url = URL.createObjectURL(file);
    try {
      const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = url; });
      const k = Math.min(1, 1920 / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      const m = document.createElement('canvas'); m.width = m.height = 32;
      const mx = m.getContext('2d'); mx.drawImage(c, 0, 0, 32, 32);
      const px = mx.getImageData(0, 0, 32, 32).data, rgb = [0, 0, 0];
      for (let i = 0; i < px.length; i += 4) { rgb[0] += px[i]; rgb[1] += px[i + 1]; rgb[2] += px[i + 2]; }
      for (let j = 0; j < 3; j++) rgb[j] = Math.round(rgb[j] / 1024);
      BGIMG = { src: c.toDataURL('image/jpeg', .82), rgb, l: (.2126 * rgb[0] + .7152 * rgb[1] + .0722 * rgb[2]) / 255 };
      let kept = true;
      try { localStorage.setItem('lk:bgimg', JSON.stringify(BGIMG)); } catch { kept = false; }   // не влезло: фото остаётся до перезагрузки
      this.set('bg', 'photo');
      return kept;
    } finally { URL.revokeObjectURL(url); }
  },
  set(k, v) {
    UI[k] = v;
    try { localStorage.setItem('lk:ui', JSON.stringify(UI)); } catch { }
    applyUI();
    if (k === 'dock') { buildDock(); measure(); markDock(false); }
    if (k === 'calm') { if (!reduced() && !orbRAF) orbRAF = requestAnimationFrame(orbLoop); drawOrbs(performance.now()); }
  }
};
window.lkMy = { add: addMy, del: delMy, has: id => Object.values(MY).some(l => l.some(o => o.id === id)) };
window.lkBack = back;
window.lkView = () => curView;
window.lkLogout = () => { window.ZK.closeSheet(); $('#app').hidden = true; $('#login').hidden = false; };
document.addEventListener('click', e => {
  if (e.target.closest('[data-back]')) return back();
  const g = e.target.closest('[data-go]'); if (g) go(g.dataset.go);
});

/* ---------- Календарь: семантический зум ---------- */
const LEVELS = ['Год', 'Месяц', 'Неделя', 'День', 'Час'];
const ZK = tok('--zoom-k'), ZC = tok('--zoom-c'), GAIN = 1.6;
const stage = $('#cal-stage'), layers = $$('.lvl', stage);
const cal = { Z: spring(2, .0005), F: today0(), hour: clamp(new Date().getHours(), H0, H1 - 1), origin: null, built: [], level: -1, gesture: false, raw: 2, vel: 0, lastT: 0, floor: 2 };

function nowLine(from, span) {
  const m = nowMin();
  if (m < from || m > from + span) return '';
  return `<div class="now" data-from="${from}" data-span="${span}" style="top:${((m - from) / span * 100).toFixed(2)}%"><span>${fm(m)}</span></div>`;
}
function renderYear() {
  const y = cal.F.getFullYear(), t = today0();
  let h = `<div class="yr" role="grid" aria-label="${y} год">`;
  for (let m = 0; m < 12; m++) {
    const first = new Date(y, m, 1), days = new Date(y, m + 1, 0).getDate();
    let dots = '<i class="e"></i>'.repeat(wdi(first));
    for (let d = 1; d <= days; d++) {
      const dt = new Date(y, m, d);
      dots += `<i style="--h:${(eventsFor(dt).length / 6).toFixed(2)}"${sameDay(dt, t) ? ' class="t"' : ''}></i>`;
    }
    const isT = y === t.getFullYear() && m === t.getMonth();
    h += `<button class="cell mini${isT ? ' today' : ''}" role="gridcell" data-date="${dkey(first)}" aria-label="${cap(MON[m])} ${y}"><b>${cap(MON[m])}</b><span class="mini-grid">${dots}</span></button>`;
  }
  return h + '</div>';
}
function renderMonth() {
  const y = cal.F.getFullYear(), m = cal.F.getMonth(), start = startOfWeek(new Date(y, m, 1)), t = today0();
  let h = `<div class="mo" role="grid" aria-label="${cap(MON[m])} ${y}"><div class="wd" role="row">${WD.map(w => `<span role="columnheader">${w}</span>`).join('')}</div>`;
  for (let r = 0; r < 6; r++) {
    h += '<div class="mo-row" role="row">';
    for (let c = 0; c < 7; c++) {
      const d = addDays(start, r * 7 + c), ev = eventsFor(d), isT = sameDay(d, t);
      h += `<button class="cell day${d.getMonth() !== m ? ' dim' : ''}${isT ? ' today' : ''}" role="gridcell" data-date="${dkey(d)}"${isT ? ' aria-current="date"' : ''} aria-label="${d.getDate()} ${MON_G[d.getMonth()]}, занятий: ${ev.length}">
        <span class="num">${d.getDate()}</span><span class="dots">${ev.map(e => `<i style="--c:var(--ev${e.c})"></i>`).join('')}</span>${ev.slice(0, 3).map(e => `<span class="tchip" style="--c:var(--ev${e.c})">${e.t}</span>`).join('')}</button>`;
    }
    h += '</div>';
  }
  return h + '</div>';
}
function renderWeek() {
  const s = startOfWeek(cal.F), t = today0();
  let h = '<div class="wk" role="grid" aria-label="Неделя"><div role="row" style="display:contents">';
  for (let i = 0; i < 7; i++) {
    const d = addDays(s, i), ev = eventsFor(d), isT = sameDay(d, t);
    h += `<button class="cell wcol${isT ? ' today' : ''}" role="gridcell" data-date="${dkey(d)}"${isT ? ' aria-current="date"' : ''} aria-label="${dayLabel(d)}, занятий: ${ev.length}">
      <span class="wh">${WD[i]}<span class="num">${d.getDate()}</span></span>${ev.map((e, j) => `<span class="echip${j && e.s < ev[j - 1].e ? ' ov' : ''}" style="--c:var(--ev${e.c})"><time>${fm(e.s)}</time><span class="full">${e.t}</span></span>`).join('') || '<span class="wfree">Пар нет</span>'}</button>`;
  }
  return h + '</div></div>';
}
function evCard(o, k, from, span, full) {
  const top = Math.max(0, o.ev.s - from) / span * 100, bot = Math.min(span, o.ev.e - from) / span * 100;
  return `<button class="ev" data-date="${k}" data-hour="${o.ev.s / 60 | 0}" style="--c:var(--ev${o.ev.c});top:${top.toFixed(2)}%;height:calc(${(bot - top).toFixed(2)}% - 3px);left:calc(${(o.lane / o.n * 100).toFixed(2)}% + 4px);width:calc(${(100 / o.n).toFixed(2)}% - 8px)">
    <b>${o.ev.t}</b><small>${fm(o.ev.s)}–${fm(o.ev.e)} · ${o.ev.room}</small><small>${o.ev.who}${full ? ' · ' + (o.ev.c === 4 ? 'консультация' : 'занятие 90 минут') : ''}</small></button>`;
}
function nextDayWith(d) { for (let i = 1; i < 60; i++) { const x = addDays(d, i); if (eventsFor(x).length) return x; } return null; }
const LP_HINT = '<p class="lp-hint">Удерживайте пустое место, чтобы добавить своё занятие</p>';
function renderDay() {
  const k = dkey(cal.F), list = eventsFor(cal.F), t = today0(), isT = sameDay(cal.F, t), past = cal.F < t, m = nowMin();
  if (!list.length) {
    const nx = nextDayWith(cal.F);
    return `<div class="dy"><div class="glass free"><b>Пар нет</b><p class="muted">${wdi(cal.F) === 6 ? 'Воскресенье, можно отдохнуть' : 'Свободный день'}</p>
      ${nx ? `<button class="chip-btn" data-act="jump" data-date="${dkey(nx)}">Ближайшие пары: ${WD_FULL[wdi(nx)]}, ${nx.getDate()} ${MON_G[nx.getMonth()]}</button>` : ''}</div>${LP_HINT}</div>`;
  }
  let h = '<ol class="agenda">', prevEnd = null;
  list.forEach((e, i) => {
    if (prevEnd !== null && e.s > prevEnd) { const gap = e.s - prevEnd; h += `<li class="ag-gap${gap >= 60 ? ' win' : ''}" data-s="${prevEnd}" aria-hidden="true"><span>${gap >= 60 ? 'Окно' : 'Перерыв'} ${durH(gap)}</span></li>`; }
    const now = isT && e.s <= m && m < e.e, done = past || (isT && m >= e.e), clash = prevEnd !== null && e.s < prevEnd, pct = now ? (m - e.s) / (e.e - e.s) * 100 : 0;
    h += `<li class="ag" style="--c:var(--ev${e.c})"><div class="ag-time" aria-hidden="true"><b>${fm(e.s)}</b><span>${fm(e.e)}</span></div>
      <button class="ag-card${now ? ' live' : ''}${done ? ' done' : ''}${e.own ? ' own' : ''}" data-ev="${i}" data-date="${k}" data-hour="${e.s / 60 | 0}" aria-label="${fm(e.s)}–${fm(e.e)}, ${e.ty}, ${e.t}, ${e.room}, ${e.who}${now ? ', идёт сейчас' : ''}${clash ? ', пересекается с предыдущей' : ''}">
        <span class="ag-tags"><span class="tag">${e.ty}</span>${e.own ? '<span class="tag own">Моё</span>' : ''}${now ? '<span class="tag live">Идёт</span>' : ''}${clash ? '<span class="tag warn">Пересекается</span>' : ''}</span>
        <b>${e.t}</b><small>${[e.room, e.who].filter(Boolean).join(' · ')}</small>
        ${now ? `<span class="ag-prog"><i style="width:${pct.toFixed(1)}%"></i></span><small>Ещё ${durH(e.e - m)}</small>` : ''}</button></li>`;
    prevEnd = Math.max(prevEnd ?? 0, e.e);
  });
  return `<div class="dy">${h}</ol>${LP_HINT}</div>`;
}
function renderHour() {
  const k = dkey(cal.F), from = cal.hour * 60, ev = lanes(eventsFor(cal.F).filter(e => e.s < from + 60 && e.e > from));
  let hours = '', rows = '';
  for (let q = 0; q < 4; q++) { hours += `<div>${pad(cal.hour)}:${pad(q * 15)}</div>`; rows += `<div class="hrow" data-date="${k}" data-hour="${cal.hour}"></div>`; }
  return `<div class="hr"><div class="hours">${hours}</div><div class="track">${rows}${ev.map(o => evCard(o, k, from, 60, true)).join('')}
    ${sameDay(cal.F, today0()) ? nowLine(from, 60) : ''}
    ${ev.length ? '' : '<div class="glass free"><b>В этот час свободно</b><p class="muted">Занятий нет</p></div>'}</div></div>`;
}
const RENDER = [renderYear, renderMonth, renderWeek, renderDay, renderHour];
const periodOf = (L, F, hour) => [F.getFullYear(), `${F.getFullYear()}-${F.getMonth()}`, dkey(startOfWeek(F)), dkey(F), `${dkey(F)}@${hour}`][L];
const periodKey = L => periodOf(L, cal.F, cal.hour) + (L >= 3 && sameDay(cal.F, today0()) ? '@' + nowMin() : '');
function ensure(L) { const k = periodKey(L); if (cal.built[L] !== k) { layers[L].innerHTML = RENDER[L](); cal.built[L] = k; } }

// Каждый кадр: два соседних уровня, нижний «ныряет» вглубь от точки фокуса, верхний вырастает из неё
function paint() {
  const z = cal.Z.x, zc = clamp(z, 0, 4), ex = z - zc;
  let lo = Math.floor(zc), f = zc - lo;
  if (lo === 4) f = 0;
  const o = cal.origin || [stage.clientWidth / 2, stage.clientHeight / 2];
  layers.forEach((el, L) => {
    let op = 0, sc = 1;
    if (L === lo) { op = 1 - f; sc = (1 + f * 1.4) * (1 + ex * .25); }
    else if (L === lo + 1 && f > .002) { op = f; sc = .5 + .5 * f; }
    else { el.classList.remove('on'); return; }
    ensure(L);
    el.classList.add('on');
    el.style.opacity = op.toFixed(3);
    el.style.transformOrigin = `${o[0]}px ${o[1]}px`;
    el.style.transform = Math.abs(sc - 1) < 1e-4 ? '' : `scale(${sc.toFixed(4)})`;
    el.style.pointerEvents = (L === lo) === (f < .5) ? '' : 'none';
  });
  const lvl = Math.round(zc);
  WAVE.cells = [];
  if (lvl !== cal.level) {
    cal.level = lvl; header();
    if (reduced()) layers[lvl].animate([{ opacity: 0 }, { opacity: 1 }], { duration: 150 });
  }
}
const SEG_ORDER = [3, 2, 1, 0]; // слева направо: День · Неделя · Месяц · Год
function header() {
  const L = Math.max(0, cal.level), F = cal.F, t0 = today0();
  let t, sub = '';
  if (L === 0) t = String(F.getFullYear());
  else if (L === 1) { t = cap(MON[F.getMonth()]); sub = String(F.getFullYear()); }
  else if (L === 2) {
    const a = startOfWeek(F), b = addDays(a, 6), n = [0, 1, 2, 3, 4, 5, 6].reduce((s, i) => s + eventsFor(addDays(a, i)).length, 0);
    t = a.getMonth() === b.getMonth() ? `${a.getDate()}–${b.getDate()} ${MON_G[b.getMonth()]}` : `${a.getDate()} ${MON_G[a.getMonth()].slice(0, 3)} – ${b.getDate()} ${MON_G[b.getMonth()].slice(0, 3)}`;
    sub = `${n} ${plural(n, 'занятие', 'занятия', 'занятий')} за неделю`;
  } else {
    const n = eventsFor(F).length, rel = Math.round((F - t0) / 864e5);
    t = `${cap(WD_FULL[wdi(F)])}, ${F.getDate()} ${MON_G[F.getMonth()]}`;
    sub = [{ '-1': 'Вчера', 0: 'Сегодня', 1: 'Завтра' }[rel], n ? `${n} ${plural(n, 'занятие', 'занятия', 'занятий')}` : 'Пар нет'].filter(Boolean).join(' · ');
    if (L === 4) sub = `${pad(cal.hour)}:00–${pad(cal.hour + 1)}:00 · ${sub}`;
  }
  $('#cal-title').textContent = t;
  $('#cal-sub').textContent = sub;
  const now = new Date(), onToday = periodOf(L, t0, clamp(now.getHours(), H0, H1 - 1)) === periodOf(L, F, cal.hour);
  $('#cal-today').classList.toggle('dim', onToday);
  const seg = Math.min(L, 3);
  $$('.seg button').forEach(b => b.setAttribute('aria-checked', String(+b.dataset.z === seg)));
  $('.seg-lens').style.transform = `translateX(${SEG_ORDER.indexOf(seg) * 100}%)`;
  strip(L >= 3);
  $('#cal-live').textContent = `${LEVELS[L]}: ${t}`;
}
// лента дней: линза переезжает к выбранному дню
let stripWeek = '', stripIdx = -1;
function strip(show) {
  const el = $('#cal-strip');
  el.hidden = !show;
  if (!show) return;
  const s = startOfWeek(cal.F), t = today0(), wk = dkey(s) + '@' + dkey(t), idx = wdi(cal.F);
  if (wk !== stripWeek) {
    stripWeek = wk;
    el.innerHTML = '<span class="strip-lens" aria-hidden="true"></span>' + [0, 1, 2, 3, 4, 5, 6].map(i => {
      const d = addDays(s, i), n = eventsFor(d).length;
      return `<button role="tab" class="sd${sameDay(d, t) ? ' today' : ''}" data-date="${dkey(d)}" aria-label="${dayLabel(d)}, занятий: ${n}"><span>${WD[i]}</span><b>${d.getDate()}</b><i class="dd">${'<i></i>'.repeat(Math.min(n, 4))}</i></button>`;
    }).join('');
    stripIdx = -1;
  }
  const lens = $('.strip-lens', el);
  if (stripIdx < 0) { lens.style.transition = 'none'; lens.style.transform = `translateX(${idx * 100}%)`; void lens.offsetWidth; lens.style.transition = ''; }
  else lens.style.transform = `translateX(${idx * 100}%)`;
  stripIdx = idx;
  $$('.sd', el).forEach((b, i) => { b.classList.toggle('sel', i === idx); b.setAttribute('aria-selected', String(i === idx)); b.tabIndex = i === idx ? 0 : -1; });
}
let calRAF = 0, calLast = 0;
function calKick() { if (!calRAF) { calLast = performance.now(); calRAF = requestAnimationFrame(calTick); } }
function calTick(now) {
  const dt = Math.min(.032, (now - calLast) / 1000); calLast = now;
  const moving = !cal.gesture && stepSpring(cal.Z, ZK, ZC, 1, dt);
  paint();
  calRAF = moving || cal.gesture ? requestAnimationFrame(calTick) : 0;
}
function zoomTo(t, origin) {
  t = clamp(Math.round(t), 0, 4);
  if (origin !== undefined) cal.origin = origin;
  cal.Z.t = t;
  if (reduced()) { cal.Z.x = t; cal.Z.v = 0; paint(); return; }
  calKick();
}
const center = () => [stage.clientWidth / 2, stage.clientHeight / 2];
function originFor(L) {
  const el = layers[L];
  if (!el.classList.contains('on')) return center();
  const sel = L === 0 ? `[data-date="${cal.F.getFullYear()}-${pad(cal.F.getMonth() + 1)}-01"]` : L === 3 ? `.hrow[data-hour="${cal.hour}"]` : `[data-date="${dkey(cal.F)}"]`;
  const c = el.querySelector(sel);
  if (!c) return center();
  const r = c.getBoundingClientRect(), s = stage.getBoundingClientRect();
  return [r.left + r.width / 2 - s.left, r.top + r.height / 2 - s.top];
}
function pickFocus(cx, cy) {
  const el = document.elementFromPoint(cx, cy)?.closest('[data-date]');
  if (!el || !stage.contains(el)) return false;
  cal.F = parseKey(el.dataset.date);
  if (el.dataset.hour) cal.hour = +el.dataset.hour;
  return true;
}
function shift(dir) {
  const L = cal.level, F = cal.F;
  if (L === 0) cal.F = new Date(F.getFullYear() + dir, F.getMonth(), 1);
  else if (L === 1) cal.F = new Date(F.getFullYear(), F.getMonth() + dir, 1);
  else if (L === 2) cal.F = addDays(F, 7 * dir);
  else if (L === 3) cal.F = addDays(F, dir);
  else {
    let h = cal.hour + dir;
    if (h < H0) { h = H1 - 1; cal.F = addDays(F, -1); } else if (h >= H1) { h = H0; cal.F = addDays(F, 1); }
    cal.hour = h;
  }
}
// Старый вид уходит копией-призраком и тает, новый проявляется со сдвигом 24 px. Без пружины и отскока, чтобы листание было почти незаметным.
function slide(dir, mutate, from = 0) {
  const el = layers[cal.level], still = reduced();
  let ghost = null;
  if (el.classList.contains('on')) {
    ghost = el.cloneNode(true);
    ghost.classList.replace('on', 'ghost'); ghost.setAttribute('aria-hidden', 'true'); ghost.removeAttribute('data-l');
    el.after(ghost); ghost.scrollTop = el.scrollTop;
  }
  mutate(); header(); paint();
  el.style.transform = ''; el.style.opacity = '1'; scrollToNow(el);
  if (!dir) return ghost?.remove();
  const D = still ? 0 : 24, op0 = 1 - Math.min(.35, Math.abs(from) / 400);
  if (ghost) ghost.animate([{ transform: `translateX(${from}px)`, opacity: op0 }, { transform: `translateX(${from - dir * D}px)`, opacity: 0 }],
    { duration: still ? 120 : 220, easing: 'cubic-bezier(.4,0,.7,.4)', fill: 'forwards' }).onfinish = () => ghost.remove();
  el.animate([{ transform: `translateX(${from * .3 + dir * D}px)`, opacity: 0 }, { transform: 'none', opacity: 1 }],
    { duration: still ? 120 : 360, delay: still ? 0 : 50, easing: 'cubic-bezier(.2,.75,.25,1)', fill: 'backwards' });
}
// в дне сразу видна текущая или ближайшая пара, а не начало списка
function scrollToNow(el = layers[cal.level]) {
  const c = cal.level === 3 && el.querySelector('.ag-card.live, .ag-card:not(.done)');
  el.scrollTop = c ? Math.max(0, c.closest('li').offsetTop - 12) : 0;
}
function pan(dir, from = 0) { slide(dir, () => shift(dir), from); }
function jumpTo(d, hour) {
  const same = periodOf(cal.level, d, hour ?? cal.hour) === periodOf(cal.level, cal.F, cal.hour);
  if (!same) slide(d < cal.F ? -1 : 1, () => { cal.F = d; if (hour !== undefined) cal.hour = hour; });
  return !same;
}
function goToday() {
  jumpTo(today0(), clamp(new Date().getHours(), H0, H1 - 1));
  const c = layers[cal.level].querySelector('.today, .now, .ag-card.live');
  if (c) { c.classList.remove('pulse'); void c.offsetWidth; c.classList.add('pulse'); }
}
function openLesson(k, i) {
  const d = parseKey(k), e = eventsFor(d)[i], m = nowMin(), t = today0();
  const when = sameDay(d, t) ? (m < e.s ? `Начнётся через ${durH(e.s - m)}` : m < e.e ? `Идёт, осталось ${durH(e.e - m)}` : 'Уже прошла') : d < t ? 'Прошла' : 'Впереди';
  window.ZK.sheet(e.t, `<dl class="kv"><dt>Когда</dt><dd>${dayLabel(d)}, ${fm(e.s)}–${fm(e.e)}</dd><dt>Статус</dt><dd>${when}</dd><dt>Тип</dt><dd>${e.ty}</dd>
    ${e.room ? `<dt>${e.own || isStaff() ? 'Место' : 'Аудитория'}</dt><dd>${e.room}</dd>` : ''}${e.who ? `<dt>${e.own || isStaff() ? 'Кто' : 'Преподаватель'}</dt><dd>${e.who}</dd>` : ''}</dl>
    <div class="row" style="margin-top:18px;gap:8px;flex-wrap:wrap">${e.own ? `<button class="btn ghost" data-cal="del" data-id="${e.id}">Удалить из расписания</button>` : isStaff() ? '' : '<button class="btn" data-cal="study">Баллы и задания</button>'}<button class="btn ghost" data-cal="week">Вся неделя</button></div>`);
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-cal]');
  if (!b) return;
  window.ZK.closeSheet();
  if (b.dataset.cal === 'del') { delMy(b.dataset.id); window.ZK.toast('Удалено из расписания'); }
  else if (b.dataset.cal === 'week') zoomTo(2, center()); else go('study');
});

// Жесты: щипок (Pointer Events), Ctrl/⌘ + колесо и щипок трекпада (wheel + ctrlKey), Safari gesture*
const rubber = raw => raw > 4 ? 4 + Math.min(.4, (raw - 4) * .3) : raw < 0 ? Math.max(-.4, raw * .3) : raw;
function gestureStart(cx, cy) {
  const s = stage.getBoundingClientRect();
  cal.gesture = true; cal.origin = [cx - s.left, cy - s.top];
  if (Math.abs(cal.Z.x - Math.round(cal.Z.x)) < .05) pickFocus(cx, cy);
  cal.raw = cal.Z.x; cal.vel = 0; cal.lastT = performance.now(); cal.floor = Math.floor(clamp(cal.raw, 0, 4));
  calKick();
}
function gestureMove(raw, cx, cy) {
  const now = performance.now(), dt = Math.max(8, now - cal.lastT) / 1000;
  cal.vel = .7 * cal.vel + .3 * ((raw - cal.raw) / dt);
  cal.raw = raw; cal.lastT = now;
  const fl = Math.floor(clamp(raw, 0, 4));
  if (fl > cal.floor) pickFocus(cx, cy); // нырнули на уровень глубже: фокус на ячейке под пальцами
  cal.floor = fl;
  cal.Z.x = rubber(raw); cal.Z.v = 0;
  calKick();
}
function gestureEnd() {
  if (!cal.gesture) return;
  cal.gesture = false;
  const v = clamp(cal.vel, -8, 8);
  cal.Z.v = v;
  zoomTo(clamp(cal.raw, 0, 4) + v * .12); // быстрый щипок докатывается до следующего уровня
}

const ptrs = new Map();
let pinch = null, multi = false, lastTap = { t: 0, x: 0, y: 0 };
const mid = () => { const [a, b] = [...ptrs.values()]; return [(a.x + b.x) / 2, (a.y + b.y) / 2, Math.hypot(a.x - b.x, a.y - b.y) || 1]; };
stage.addEventListener('pointerdown', e => {
  if (e.button) return;
  try { stage.setPointerCapture(e.pointerId); } catch { } // синтетические указатели (тесты) захватить нельзя
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, x0: e.clientX, y0: e.clientY, t: performance.now() });
  lastPtr = e.pointerType;
  if (ptrs.size === 1) lpStart(ptrs.get(e.pointerId));
  if (ptrs.size === 2) {
    ptrs.forEach(lpCancel);
    multi = true;
    const [mx, my, d] = mid();
    gestureStart(mx, my);
    pinch = { d0: d, mx0: mx, z0: cal.Z.x };
  }
});
stage.addEventListener('pointermove', e => {
  const p = ptrs.get(e.pointerId);
  if (!p) return;
  p.x = e.clientX; p.y = e.clientY;
  if (p.lp && Math.hypot(p.x - p.x0, p.y - p.y0) > 10) lpCancel(p);
  if (p.long) return;
  if (pinch && ptrs.size >= 2) {
    const [mx, my, d] = mid(), zoom = Math.log2(d / pinch.d0);
    gestureMove(pinch.z0 + zoom * GAIN, mx, my);
    if (Math.abs(zoom) < .12 && Math.abs(mx - pinch.mx0) > 70) { pan(mx < pinch.mx0 ? 1 : -1); pinch.mx0 = mx; } // два пальца вбок — листаем время
  } else if (ptrs.size === 1 && !multi) { // один палец вбок: вид едет за пальцем с сопротивлением
    const dx = p.x - p.x0, dy = p.y - p.y0, el = layers[cal.level];
    if (!p.drag && Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.2) p.drag = true;
    if (p.drag && el) { const off = dx * .45; el.style.transform = `translateX(${off}px)`; el.style.opacity = String(1 - Math.min(.35, Math.abs(off) / 400)); }
  }
});
function ptrEnd(e) {
  const p = ptrs.get(e.pointerId);
  if (!p) return;
  ptrs.delete(e.pointerId);
  lpCancel(p);
  if (p.long) { if (!ptrs.size) multi = false; return; }   // долгое нажатие уже открыло форму, это не тап
  if (pinch) { if (ptrs.size < 2) { pinch = null; gestureEnd(); } }
  else if (!multi && e.type === 'pointerup') {
    const dx = e.clientX - p.x0, dy = e.clientY - p.y0, el = layers[cal.level];
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) pan(dx < 0 ? 1 : -1, p.drag ? dx * .45 : 0);
    else if (p.drag) { el.animate([{ transform: el.style.transform, opacity: el.style.opacity }, { transform: 'none', opacity: 1 }], { duration: 260, easing: 'cubic-bezier(.2,.8,.2,1)' }); el.style.transform = ''; el.style.opacity = '1'; }
    else if (Math.abs(dx) < 10 && Math.abs(dy) < 10 && performance.now() - p.t < 500) tap(e.clientX, e.clientY);
  }
  else if (p.drag) { const el = layers[cal.level]; el.style.transform = ''; el.style.opacity = '1'; } // прокрутка забрала жест
  if (!ptrs.size) multi = false;
}
stage.addEventListener('pointerup', ptrEnd);
// Долгое нажатие на пустое место (на мыши ещё и правая кнопка) открывает форму своего занятия
let lpEl = null, lastPtr = 'mouse';
function lpTarget(cx, cy) {
  const el = document.elementFromPoint(cx, cy), L = cal.level;
  if (!el || !stage.contains(el) || el.closest('.ag-card, .ev, .echip, .tchip, [data-act], .side, .chip-btn')) return null;
  if (L === 4) { const t = el.closest('.track'); if (!t) return null; const r = t.getBoundingClientRect(); return { k: dkey(cal.F), s: cal.hour * 60 + clamp(Math.floor((cy - r.top) / r.height * 4), 0, 3) * 15 }; }
  if (L === 3) { if (!el.closest('.dy')) return null; const g = el.closest('.ag-gap'); return { k: dkey(cal.F), s: g ? +g.dataset.s : freeAt(cal.F) }; }
  const c = el.closest('.wcol, .cell.day');
  return c ? { k: c.dataset.date, s: freeAt(parseKey(c.dataset.date)) } : null;
}
function lpStart(p) {
  const t = lpTarget(p.x, p.y);
  if (!t) return;
  p.lp = setTimeout(() => { p.lp = 0; p.long = true; lpStop(); navigator.vibrate?.(12); openCreate(t.k, t.s); }, 520);
  if (reduced()) return;
  // кольцо появляется через 180 мс: обычный тап и начало прокрутки его не показывают
  p.ring = setTimeout(() => {
    lpEl = document.createElement('i'); lpEl.className = 'lp-ring'; lpEl.setAttribute('aria-hidden', 'true');
    lpEl.style.left = p.x + 'px'; lpEl.style.top = p.y + 'px'; document.body.append(lpEl);
  }, 180);
}
function lpStop() { lpEl?.remove(); lpEl = null; }
function lpCancel(p) { if (p) { clearTimeout(p.lp); clearTimeout(p.ring); p.lp = 0; } lpStop(); }
stage.addEventListener('contextmenu', e => {
  const t = lpTarget(e.clientX, e.clientY);
  if (!t) return;
  e.preventDefault();                       // на телефоне форму уже открыл таймер, системное меню не нужно
  if (lastPtr === 'mouse') openCreate(t.k, t.s);
});
const TY_OWN = ['Своё дело', 'Занятие', 'Консультация', 'Мероприятие'];
function openCreate(k, s) {
  const e = Math.min(s + 90, 1435);
  window.ZK.sheet('Новое занятие', `<form id="myEv" class="my-form" novalidate>
    <div class="field"><label for="my-t">Название</label><input id="my-t" name="t" maxlength="80" placeholder="Например, подготовка к коллоквиуму" autocomplete="off"></div>
    <div class="field"><label for="my-ty">Тип</label><select id="my-ty" name="ty">${TY_OWN.map(x => `<option>${x}</option>`).join('')}</select></div>
    <div class="my-row"><div class="field"><label for="my-d">Дата</label><input id="my-d" name="d" type="date" value="${k}"></div>
      <div class="field"><label for="my-s">Начало</label><input id="my-s" name="s" type="time" step="300" value="${fm(s)}"></div>
      <div class="field"><label for="my-e">Конец</label><input id="my-e" name="e" type="time" step="300" value="${fm(e)}"></div></div>
    <div class="field"><label for="my-r">Место</label><input id="my-r" name="room" maxlength="60" placeholder="Аудитория, адрес или ссылка" autocomplete="off"></div>
    <p class="err" hidden></p>
    <button class="btn block" type="submit">Добавить в расписание</button></form>`);
}
document.addEventListener('submit', ev => {
  if (ev.target.id !== 'myEv') return;
  ev.preventDefault();
  const f = ev.target.elements, err = ev.target.querySelector('.err'), clean = v => v.trim().replace(/[<>"&]/g, '');
  const toM = v => { const [h, m] = (v || '').split(':').map(Number); return h * 60 + m; };
  const t = clean(f.t.value), s = toM(f.s.value), e = toM(f.e.value);
  const bad = !t ? ['Напишите название', f.t] : !f.d.value ? ['Выберите дату', f.d] : !(e > s) ? ['Конец должен быть позже начала', f.e] : null;
  if (bad) { err.textContent = bad[0]; err.hidden = false; bad[1].focus(); return; }
  addMy(f.d.value, { id: 'my' + Date.now().toString(36), s, e, t, ty: f.ty.value, room: clean(f.room.value), who: '' });
  window.ZK.closeSheet();
  window.ZK.toast(`«${t}» в расписании`);
  if (curView === 'schedule') jumpTo(parseKey(f.d.value), clamp(s / 60 | 0, H0, H1 - 1));
});
stage.addEventListener('pointercancel', ptrEnd);
/* ---------- Волна по ячейкам: дни, недели и месяцы под курсором или пальцем приподнимаются
   с гауссовым спадом, как иконки дока. Мышь — при наведении, палец — пока прижат к сетке (до начала свайпа) ---------- */
const WAVE = { x: null, y: null, raf: 0, cells: [], L: -1 };
function waveCells() {
  const el = layers[cal.level];
  if (WAVE.L !== cal.level || !WAVE.cells.length || !WAVE.cells[0].isConnected) {
    WAVE.L = cal.level;
    WAVE.cells = el && cal.level < 3 ? $$('.cell', el) : [];
  }
  return WAVE.cells;
}
function waveFrame() {
  WAVE.raf = 0;
  const cells = waveCells(), on = WAVE.x !== null && !reduced() && cells.length;
  if (!cells.length) return;
  const r0 = cells[0].getBoundingClientRect(), sig = Math.max(46, Math.hypot(r0.width, r0.height) * .62);
  cells.forEach(c => {
    let g = 0;
    if (on) {
      const r = c.getBoundingClientRect(), dx = WAVE.x - (r.left + r.width / 2), dy = WAVE.y - (r.top + r.height / 2);
      g = Math.exp(-(dx * dx + dy * dy) / (2 * sig * sig));
      if (g < .03) g = 0;
    }
    c.style.translate = g ? `0 ${(-7 * g).toFixed(2)}px` : '';
    c.style.scale = g ? (1 + .07 * g).toFixed(4) : '';
    c.style.zIndex = g > .3 ? '1' : '';
    c.style.setProperty('--wv', g.toFixed(3));
  });
}
function waveAt(x, y) { WAVE.x = x; WAVE.y = y; if (!WAVE.raf) WAVE.raf = requestAnimationFrame(waveFrame); }
const waveOff = () => { if (WAVE.x !== null) waveAt(null, null); };
stage.addEventListener('pointermove', e => {
  const p = ptrs.get(e.pointerId);
  if (e.pointerType === 'mouse' ? !e.buttons : p && !p.drag && !pinch && ptrs.size === 1) waveAt(e.clientX, e.clientY);
  else waveOff();
}, { passive: true });
stage.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse') waveAt(e.clientX, e.clientY); else waveOff(); }, { passive: true });
['pointerup', 'pointercancel', 'pointerleave', 'wheel'].forEach(t => stage.addEventListener(t, e => { if (t !== 'pointerup' || e.pointerType !== 'mouse') waveOff(); }, { passive: true }));
function tap(cx, cy) {
  const el = document.elementFromPoint(cx, cy);
  if (!el) return;
  if (el.closest('[data-act="today"]')) return goToday();
  const jump = el.closest('[data-act="jump"]');
  if (jump) return jumpTo(parseKey(jump.dataset.date));
  const card = el.closest('.ag-card');
  if (card) return openLesson(card.dataset.date, +card.dataset.ev);
  const cell = el.closest('[data-date]'), now = performance.now(), s = stage.getBoundingClientRect();
  if (!cell || cal.level === 4) { // двойной тап по пустому месту — на уровень выше
    if (now - lastTap.t < 320 && Math.hypot(cx - lastTap.x, cy - lastTap.y) < 30) { zoomTo(cal.level - 1, center()); lastTap.t = 0; }
    else lastTap = { t: now, x: cx, y: cy };
    return;
  }
  pickFocus(cx, cy);
  zoomTo(cal.level === 1 ? 3 : cal.level + 1, [cx - s.left, cy - s.top]); // из месяца — сразу в день
}
let wheelAcc = 0, wheelCool = 0, wheelEnd;
stage.addEventListener('wheel', e => {
  const k = e.deltaMode === 1 ? 16 : 1;
  if (!e.ctrlKey && !e.metaKey && Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return; // вертикаль — обычная прокрутка списка
  e.preventDefault();
  if (e.ctrlKey || e.metaKey) {
    if (!cal.gesture) gestureStart(e.clientX, e.clientY);
    gestureMove(cal.raw - e.deltaY * k * .012, e.clientX, e.clientY);
    clearTimeout(wheelEnd); wheelEnd = setTimeout(gestureEnd, 160);
    return;
  }
  const now = performance.now();
  if (now < wheelCool) return;
  wheelAcc += e.deltaX * k;
  if (Math.abs(wheelAcc) > 60) { pan(Math.sign(wheelAcc)); wheelAcc = 0; wheelCool = now + 350; }
}, { passive: false });
if ('GestureEvent' in window && !navigator.maxTouchPoints) { // Safari на macOS: щипок трекпада
  let g0 = 0;
  stage.addEventListener('gesturestart', e => { e.preventDefault(); gestureStart(e.clientX, e.clientY); g0 = cal.Z.x; });
  stage.addEventListener('gesturechange', e => { e.preventDefault(); gestureMove(g0 + Math.log2(e.scale) * GAIN, e.clientX, e.clientY); });
  stage.addEventListener('gestureend', e => { e.preventDefault(); gestureEnd(); });
}
$('#cal-prev').addEventListener('click', () => pan(-1));
$('#cal-next').addEventListener('click', () => pan(1));
$('#cal-today').addEventListener('click', goToday);
const stripEl = $('#cal-strip');
let stripX = null;
stripEl.addEventListener('pointerdown', e => { stripX = e.clientX; });
stripEl.addEventListener('pointerup', e => {
  const dx = stripX === null ? 0 : e.clientX - stripX; stripX = null;
  if (Math.abs(dx) > 40) { slide(dx < 0 ? 1 : -1, () => { cal.F = addDays(cal.F, dx < 0 ? 7 : -7); }); return; }
  const b = e.target.closest('.sd');
  if (b) jumpTo(parseKey(b.dataset.date));
});
stripEl.addEventListener('keydown', e => {
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  e.preventDefault(); e.stopPropagation();
  pan(e.key === 'ArrowLeft' ? -1 : 1);
  $('.sd.sel', stripEl)?.focus();
});
$$('.seg button').forEach(b => b.addEventListener('click', () => {
  const z = +b.dataset.z;
  zoomTo(z, z > cal.level ? originFor(cal.level) : center());
}));
document.addEventListener('keydown', e => {
  if ($('#v-schedule').hidden || e.target.matches?.('input, textarea') || dock.contains(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.key === '+' || e.key === '=') zoomTo(cal.level + 1, originFor(cal.level));
  else if (e.key === '-' || e.key === '_') zoomTo(cal.level - 1, center());
  else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') pan(-1);
  else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') pan(1);
  else if (e.code === 'KeyT') goToday();
  else return;
  e.preventDefault();
});

/* ---------- Часы и линия «сейчас» ---------- */
let calMin = -1;
function tickClock() {
  if (!$('#v-home').hidden && !$('#app').hidden) tickHome();
  if (nowMin() !== calMin) { calMin = nowMin(); if (!$('#v-schedule').hidden && cal.level >= 3) paint(); }
  const m = nowMin();
  $$('.lvl .now').forEach(el => {
    el.style.top = ((m - +el.dataset.from) / +el.dataset.span * 100).toFixed(2) + '%';
    el.firstChild.textContent = fm(m);
  });
}
tickClock();
setInterval(tickClock, 1000);

/* ---------- Фон: шары медленно плавают и чуть следуют за курсором ---------- */
// [x, y — доли экрана, d — диаметр в долях ширины, b — голубой/w — белый]; раскладка повторяет прежнюю картинку
const ORBS_WIDE = [[.07, .18, .21, 'b'], [.17, .06, .045, 'w'], [.02, .5, .27, 'w'], [.17, .5, .12, 'w'], [.13, .7, .05, 'b'], [.06, .88, .16, 'b'], [.17, .9, .085, 'w'],
  [.93, .14, .23, 'w'], [.79, .22, .06, 'w'], [.85, .43, .18, 'b'], [.95, .6, .07, 'b'], [.8, .86, .11, 'b'], [.94, .88, .26, 'w']];
const ORBS_TALL = [[.04, .08, .46, 'b'], [.5, .04, .1, 'w'], [1, .12, .52, 'w'], [.76, .25, .18, 'b'], [.26, .22, .09, 'b'],
  [.62, .74, .11, 'w'], [0, .84, .44, 'w'], [.36, .95, .26, 'b'], [.74, .97, .18, 'b'], [.98, .82, .5, 'w']];
const bgEl = $('#bg'), mouse = { x: 0, y: 0, tx: 0, ty: 0 };
let orbs = [], orbRAF = 0;
function layoutOrbs() {
  const w = innerWidth, h = innerHeight, list = w / h < 1 ? ORBS_TALL : ORBS_WIDE;
  $$('.orb', bgEl).forEach(o => o.remove());
  orbs = list.map(([x, y, d, k], i) => {
    const el = document.createElement('i'), size = d * w, r = hash('orb' + i);
    el.className = `orb ${k}${d < .05 ? ' far' : ''}`;
    el.style.setProperty('--d', size.toFixed(0) + 'px');
    bgEl.append(el);
    // крупные — ближе к зрителю: сильнее параллакс и шире дрейф (12–34 px); период медленный, 20–36 с
    return { el, x: x * w, y: y * h, depth: .3 + d * 3, ax: 12 + r % 12 + d * 40, ay: 12 + (r >>> 4) % 12 + d * 30,
      fx: 2 * Math.PI / (20 + (r >>> 8) % 17), fy: 2 * Math.PI / (20 + (r >>> 12) % 17), ph: (r >>> 16) % 628 / 100 };
  });
  drawOrbs(performance.now());
}
function drawOrbs(now) {
  const t = now / 1000, still = reduced();
  mouse.x += (mouse.tx - mouse.x) * .025; mouse.y += (mouse.ty - mouse.y) * .025;
  for (const o of orbs) {
    const dx = still ? 0 : Math.sin(t * o.fx + o.ph) * o.ax - mouse.x * 18 * o.depth;
    const dy = still ? 0 : Math.cos(t * o.fy + o.ph * 1.3) * o.ay - mouse.y * 12 * o.depth;
    o.el.style.transform = `translate3d(${(o.x + dx).toFixed(1)}px, ${(o.y + dy).toFixed(1)}px, 0)`;
  }
}
function orbLoop(now) { drawOrbs(now); orbRAF = reduced() ? 0 : requestAnimationFrame(orbLoop); }
addEventListener('pointermove', e => { if (e.pointerType === 'mouse') { mouse.tx = e.clientX / innerWidth - .5; mouse.ty = e.clientY / innerHeight - .5; } }, { passive: true });
let orbResize;
addEventListener('resize', () => { clearTimeout(orbResize); orbResize = setTimeout(layoutOrbs, 120); });
reduceMQ.addEventListener('change', () => { if (!orbRAF) orbRAF = requestAnimationFrame(orbLoop); drawOrbs(performance.now()); });
layoutOrbs();
if (!reduced()) orbRAF = requestAnimationFrame(orbLoop);

/* ---------- Поиск на главной: кнопка-капля раскрывается в стеклянную строку ---------- */
const srch = $('#search'), sBtn = $('#s-open'), sPill = $('.s-pill', srch), sRes = $('.s-res', srch), sIn = $('#s-input'), sList = $('#s-list');
const sP = spring(0, .002);
let sRAF = 0, sLast = 0, sFrom = null, sTo = null, sHits = [], sSel = 0, sIndex = null;
const SEARCH_EXTRA = () => {
  const out = [], have = new Set(), who = {};
  const subjects = subjectsForAccount();
  if (!isStaff()) subjects.forEach(([t, w]) => { (who[w] = who[w] || []).push(t); });
  subjects.forEach(([t, w]) => out.push({ g: isStaff() ? 'Разделы' : 'Предметы', t, s: `Расписание · ${w}`, k: 'расписание', ic: 'schedule', run: () => go('schedule') }));
  Object.entries(who).forEach(([t, l]) => out.push({ g: 'Преподаватели', t, s: l.join(', '), k: 'преподаватель', ic: 'user', run: () => go('schedule') }));
  [['schedule', 'Расписание', 'Пары на день, неделю, месяц', 'календарь пары занятия'], ['study', 'Успеваемость', 'Рейтинг, посещаемость, баллы, сессия, зачётка', 'учёба успеваемость оценки рейтинг посещаемость стипендия рекомендации'],
    ['docs', 'Документы', 'Заказать справку, подать заявление, архив', 'справки заявки документы архив'], ['inbox', 'Уведомления', 'Мессенджер, новости, мероприятия', 'новости чат мессенджер мероприятия афиша'], ['profile', 'Профиль', 'Студбилет и учебные данные', 'аккаунт'], ['settings', 'Настройки', 'Безопасность, уведомления, выход', 'настройки пароль устройства выход'], ['settings', 'Внешний вид', 'Тема, жидкое стекло, часы, фон', 'тема темная светлая стекло часы оформление фон обои картинка фото оттенок'], ['access', 'Универсальный доступ', 'Иконки и порядок дока, крупный текст', 'доступность док иконки текст движение']]
    .forEach(([id, t, s, k]) => {
      if (isStaff() && id === 'docs') return;
      if (isStaff() && id === 'study') [t,s,k] = ['Заявки студентов','Очередь учебного офиса','заявка статус'];
      if (isStaff() && id === 'profile') [s,k] = ['Должность, подразделение и контакты','аккаунт сотрудник'];
      if (isStaff() && id === 'schedule') [s,k] = ['Рабочий график','календарь приём'];
      out.push({ g: 'Разделы', t, s, k, ic: { schedule: 'schedule', study: 'grades', docs: 'requests', inbox: 'inbox', profile: 'profile', settings: 'shield', access: 'user' }[id], run: () => go(id) });
    });
  return out.filter(it => { const key = it.g + it.t; return !have.has(key) && have.add(key); });
};
const GROUP_ORDER = ['Разделы', 'Предметы', 'Преподаватели', 'Студенты', 'Мероприятия', 'Справки и заявления', 'Мои заявки', 'Оценки', 'Дедлайны', 'Уведомления', 'Профиль'];
const norm = s => s.toLowerCase().replace(/ё/g, 'е');
// набрано в английской раскладке → русская (ghtgjlfdfntkm → преподаватель)
const EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,.`", RU = 'йцукенгшщзхъфывапролджэячсмитьбюё';
const swapLayout = s => [...s].map(c => { const i = EN.indexOf(c); return i < 0 ? c : RU[i]; }).join('');
function buildIndex() {
  const seen = new Set();
  sIndex = [...(window.ZK?.searchItems() || []), ...SEARCH_EXTRA()].filter(it => { const key = it.g + norm(it.t); return !seen.has(key) && seen.add(key); })
    .map(it => ({ ...it, nt: norm(it.t), all: norm(`${it.t} ${it.s} ${it.k || ''} ${it.g}`) }));
}
function score(it, toks) {
  let sc = 0;
  for (const tk of toks) {
    if (!it.all.includes(tk)) return 0;
    sc += it.nt.startsWith(tk) ? 6 : new RegExp('(^|[\\s«(-])' + tk.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(it.nt) ? 4 : it.nt.includes(tk) ? 2 : 1;
  }
  return sc;
}
function find(q) {
  const toks = norm(q).trim().split(/\s+/).filter(Boolean);
  if (!toks.length) return null;
  let hits = sIndex.map(it => [it, score(it, toks)]).filter(x => x[1]);
  if (!hits.length && /[a-z]/i.test(q)) { const alt = swapLayout(norm(q)).trim().split(/\s+/); hits = sIndex.map(it => [it, score(it, alt)]).filter(x => x[1]); }
  return hits.sort((a, b) => b[1] - a[1] || GROUP_ORDER.indexOf(a[0].g) - GROUP_ORDER.indexOf(b[0].g)).slice(0, 24).map(x => x[0]);
}
const escH = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function hl(text, q) {
  let h = escH(text);
  norm(q).trim().split(/\s+/).filter(t => t.length > 1).forEach(tk => {
    const i = norm(text).indexOf(tk);
    if (i >= 0) h = escH(text.slice(0, i)) + '<mark>' + escH(text.slice(i, i + tk.length)) + '</mark>' + escH(text.slice(i + tk.length));
  });
  return h;
}
function renderHits() {
  const q = sIn.value, found = find(q);
  const SUGGEST = ['Справка об обучении', 'Базы данных', 'Петров Д. С.', 'Материальная помощь', 'Студенческий билет'];
  // группы идут в порядке своего лучшего результата, внутри группы порядок по релевантности: одна группа не разрывается
  const gOrder = found ? [...new Set(found.map(it => it.g))] : [];
  sHits = found ? found.slice().sort((a, b) => gOrder.indexOf(a.g) - gOrder.indexOf(b.g)) : SUGGEST.map(t => sIndex.find(it => it.t === t)).filter(Boolean);
  sSel = 0;
  if (!sHits.length) { sList.innerHTML = `<p class="s-empty">По запросу «${escH(q)}» ничего нет. Попробуйте название предмета, фамилию или «справка».</p>`; return; }
  let g = '', html = found ? '' : '<p class="s-g">Часто ищут</p>';
  sHits.forEach((it, i) => {
    if (found && it.g !== g) { g = it.g; html += `<p class="s-g">${g}</p>`; }
    html += `<button class="s-it" role="option" id="s-o${i}" data-i="${i}" aria-selected="${i === 0}" tabindex="-1"><span class="ico">${window.ZK?.icon(it.ic) || ''}</span><span><b>${hl(it.t, q)}</b><small>${escH(it.s)}</small></span></button>`;
  });
  sList.innerHTML = html;
  sIn.setAttribute('aria-activedescendant', 's-o0');
}
function select(i) {
  if (!sHits.length) return;
  sSel = (i + sHits.length) % sHits.length;
  $$('.s-it', sList).forEach(b => b.setAttribute('aria-selected', +b.dataset.i === sSel));
  const el = $('#s-o' + sSel); el?.scrollIntoView({ block: 'nearest' });
  sIn.setAttribute('aria-activedescendant', 's-o' + sSel);
}
function sGeom() {
  const b = sBtn.getBoundingClientRect(), home = $('#v-home'), cs = getComputedStyle(home), hr = home.getBoundingClientRect();
  const left = hr.left + parseFloat(cs.paddingLeft), width = Math.min(hr.width - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight), 680);
  const narrow = innerWidth < 640, h = narrow ? 54 : 60;
  // на телефоне строка уходит наверх (там место под клавиатуру), на большом экране остаётся у часов
  const top = narrow ? 16 + (parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--sat')) || 0) : clamp(b.top + b.height / 2 - h / 2, 16, innerHeight * .4);
  sFrom = { x: b.left, y: b.top, w: b.width, h: b.height };
  sTo = { x: left + (hr.width - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - width) / 2, y: top, w: width, h };
}
function sPaint() {
  const p = sP.x, L = (a, b) => a + (b - a) * p, f = sFrom, t = sTo;
  Object.assign(sPill.style, { left: L(f.x, t.x) + 'px', top: L(f.y, t.y) + 'px', width: L(f.w, t.w) + 'px', height: L(f.h, t.h) + 'px' });
  const pr = clamp((p - .55) / .45, 0, 1);
  Object.assign(sRes.style, { left: t.x + 'px', top: t.y + t.h + 10 + 'px', width: t.w + 'px', maxHeight: `calc(100dvh - ${t.y + t.h + 10}px - var(--dock-h) - 40px)` });
  srch.style.setProperty('--p', clamp(p, 0, 1)); srch.style.setProperty('--pi', clamp((p - .4) / .6, 0, 1)); srch.style.setProperty('--pr', pr);
  sRes.style.visibility = pr > .01 ? 'visible' : 'hidden';
}
function sStep(now) {
  const dt = Math.min(.032, (now - sLast) / 1000 || .016); sLast = now;
  const moving = stepSpring(sP, 240, 24, 1, dt);
  sPaint();
  if (moving) sRAF = requestAnimationFrame(sStep);
  else { sRAF = 0; if (sP.t === 0) { srch.hidden = true; sBtn.setAttribute('aria-expanded', 'false'); } }
}
function sAnimate(to) {
  sP.t = to;
  if (reduced()) { sP.x = to; sPaint(); if (!to) { srch.hidden = true; sBtn.setAttribute('aria-expanded', 'false'); } return; }
  if (!sRAF) { sLast = performance.now(); sRAF = requestAnimationFrame(sStep); }
}
function openSearch() {
  if (!srch.hidden && sP.t === 1) return;
  buildIndex(); sGeom();
  srch.hidden = false; sBtn.setAttribute('aria-expanded', 'true');
  sIn.value = ''; renderHits(); sPaint();
  sIn.focus({ preventScroll: true });
  sAnimate(1);
}
function closeSearch(back = true) {
  if (srch.hidden || sP.t === 0) return;
  sGeom(); sIn.blur(); sAnimate(0);
  if (back) sBtn.focus({ preventScroll: true });
}
function runHit(i) {
  const it = sHits[i]; if (!it) return;
  sP.t = 0; sP.x = 0; srch.hidden = true; sBtn.setAttribute('aria-expanded', 'false'); cancelAnimationFrame(sRAF); sRAF = 0;
  it.run();
}
sBtn.addEventListener('click', openSearch);
$('#s-close').addEventListener('click', () => closeSearch());
$('.s-scrim', srch).addEventListener('click', () => closeSearch());
sIn.addEventListener('input', renderHits);
sList.addEventListener('click', e => { const b = e.target.closest('.s-it'); if (b) runHit(+b.dataset.i); });
sList.addEventListener('pointermove', e => { const b = e.target.closest('.s-it'); if (b && +b.dataset.i !== sSel) select(+b.dataset.i); });
sIn.addEventListener('keydown', e => {
  if (e.key === 'ArrowDown') select(sSel + 1);
  else if (e.key === 'ArrowUp') select(sSel - 1);
  else if (e.key === 'Enter') runHit(sSel);
  else if (e.key === 'Escape') closeSearch();
  else return;
  e.preventDefault(); e.stopPropagation();
});
// «/» или ⌘K/Ctrl+K открывают поиск с главной
document.addEventListener('keydown', e => {
  if ($('#app').hidden || !srch.hidden) return;
  const typing = /INPUT|TEXTAREA/.test(document.activeElement?.tagName);
  if ((e.key === '/' && !typing) || ((e.metaKey || e.ctrlKey) && e.code === 'KeyK')) { e.preventDefault(); if ($('#v-home').hidden) go('home'); openSearch(); }
});
addEventListener('resize', () => { if (!srch.hidden) { sGeom(); sPaint(); } });

/* ---------- Прямая ссылка на экран: после успешного входа ---------- */
function openDeepLink() {
  const [view, arg] = decodeURIComponent(location.hash.slice(1)).split(':');
  if (!view) return;
  if (view === 'search') { openSearch(); if (arg) { sIn.value = arg; renderHits(); } return; }
  if (view === 'lesson') { go('schedule'); zoomTo(3); const d = eventsFor(today0()).length ? today0() : nextDayWith(today0()); cal.F = d; header(); paint(); openLesson(dkey(d), 0); return; }
  go(view);
  if (view === 'schedule' && arg) zoomTo(+arg);
  if (view === 'inbox' && arg) window.ZK.inbox(arg);
  if (view === 'docs' && arg) arg === 'order' ? window.ZK.order('study') : window.ZK.picker(arg === 'app' ? 'app' : arg === 'archive' ? 'archive' : 'cert');
}
